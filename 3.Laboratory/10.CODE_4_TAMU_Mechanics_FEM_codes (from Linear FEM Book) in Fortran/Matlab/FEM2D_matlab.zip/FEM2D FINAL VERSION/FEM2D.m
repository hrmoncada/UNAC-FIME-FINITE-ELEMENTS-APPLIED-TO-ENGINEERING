function FEM2D

%     Program name: FEM2D         Length (including blanks):....lines
%       
%    * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
%    *                        Program  FEM2D                         *
%    *          (A FINITE ELEMENT ANALYSIS COMPUTER PROGRAM)         *
%    * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
%    . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
%    .                                                               .
%    .     This  is  a  finite  element  computer  program  for  the .
%    . analysis of two-dimensional problems governed by second-order .
%    . partial  differential  equations  arising in:  heat transfer, .
%    . electrical engineering, fluid dynamics, and solid mechanics.  .
%    .                                                               .
%    .     The  program  uses  linear and quadratic,  triangular and .
%    . rectangular, elements with isoparametri% formulations. Meshes .
%    . of only one type of element are allowed for a problem  (i.e., .
%    . two different types of elements cannot be used in a problem). .
%    .                                                               .
%    .     Many  field  problems  of engineering and applied science .
%    . can be analyzed using this program.  In  particular,  FEM2DV2 .
%    . can be used in the finite element analysis of problems in the .
%    . following fields:                                             .
%    .                                                               .
%    .     1.  Heat conduction and convection                        .
%    .     2.  Flows of viscous incompressible fluids (by penalty    .
%    .         function formulation)                                 .
%    .     3.  Plane elasticity problems                             .
%    .     4.  Plate bending problems using rectangular elements     .
%    .         based on the classical and first-order (or Mindlin)   .
%    .         plate theory.                                         .
%    .                                                               .
%    .     The main objective of this  program  is to illustrate how .
%    . finite element formulations developed in  Chapters  8 thru 12 .
%    . can be implemented on a computer  and used in the analysis of .
%    . engineering problems.  Modeling of large and complex problems .
%    . was not an objective of the program.  The program or parts of .
%    . it can be modified to analyze field problems not discussed in .
%    . the book.                                                     .
%    . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
%
%           DESCRIPTION OF SOME KEY VARIABLES USED IN THE PROGRAM
%    (See Table 13.1 of the BOOK for a description of other variables)
%
%      [CMAT]    Matrix of stiffnesses in elasticity and plate bending
%                problems (computed  in  the  program from engineering
%                constants, E1, E2, G12, ANU12, etc. and thickness)
%
%      {ELA}     Vector of elemental nodal accelerations
%      {ELF}     Vector of element nodal source (or force) vector
%      [ELK]     Element coefficient (or stiffness) matrix
%      {ELU}     Vector of element nodal values of primary variables
%      {ELV}     Vector of elemental nodal velocities
%      {ELXY}    Vector of elemental global coordinates:
%                ELXY(I,1)=x-coordinate;  ELXY(I,2)=y-coordinate
%      {GLA}     Vector of global nodal accelerations
%      {GLF}     Vector of global nodal source (or force) vector
%      [GLK]     Global coefficient (or stiffness) matrix
%      {GLU}     Vector of global nodal values of primary variables
%      {GLV}     Vector of global nodal velocities
%
%      NDF       Number of degrees of freedom per node:
%                NDF=1, For SINGLE VARIABLE problems
%                NDF=2, For ELASTICITY and VISCOUS FLUID FLOW
%                NDF=3, For PLATE BENDING when FSDT or CST(N)
%                       elements are used
%                NDF=4, For PLATE BENDING when CST(C) element
%                       is used
%
%      NEQ       Total number of equations in the problem (=NNM*NDF)
%      NHBW      Half band width of the global coefficient matrix, GLK
%      NN        Total number of degrees of freedom per element
%      ---------------------------------------------------------------
%
%      ---------------------------------------------------------------
%                      SUBROUTINES COMMON TO THE FORTRAN PROGRAM
%
% BOUNDARY,CONCTVTY,EGNBNDRY,ELKMFRCT,ELKMFTRI, EQNSOLVR,MESH2DG,MESH2DR,
% QUADRTRI,SHAPERCT,SHAPETRI,TEMPORAL
%
%      ---------------------------------------------------------------
%                      SUBROUTINES ADDED TO THE MATLAB PROGRAM
%
%   INPUT:     read input file and save in data
%   PrintOUT:  print and plot output results                
%   IntStress: replaces POSTPROC
%   lgwt:      Computes the Legendre-Gauss nodes and weights
%   SOLVE:     contains FORTRAN lines 565->766.
%   eig:       solve eigenvalue problem
%
%      ---------------------------------------------------------------
%                      FORTRAN SUBROUTINES DELETED IN THE MATLAB PROGRAM
% DATAECHO,EGNSOLVR,INVERSE,JACOBI,MATRXMLT,POSTPROC

addpath('results\'); addpath('Subroutines\');
%% read input name
filename='Ex9-5-3'; %without extension: it is automatically   filename.inp

if isempty(filename==1)
    prompt = {'Enter Input name:'};
    answer = inputdlg(prompt) 
    filename=answer{1}; %convert cell to string 
end
filein = join([filename,'.inp']);
fileout = join([filename,'.out']);


%% | PREPROCESSOR UNIT |
%|_______________________________________________|
data=INPUT(filein,fileout);

%%  |PROCESSOR UNIT|
%     Counter on number of TIME steps begins here
NCOUNT=1;
[data,GLF] = SOLVE(data,NCOUNT,fileout);

if(data.NEIGN~=1) 
    if(data.ITEM==2)
    %     For nonzero initial conditions, GLF in the very first solution
    %     is the acceleration, {A}=[MINV]({F}-[K]{U})
        data.GLA=GLF;
        [data,GLF]= SOLVE(data,NCOUNT);
    end
%%
%     Compute the difference between solutions at two consecutive times,
%     and calculate new velocities and accelerations
%
    if(data.ITEM~=0)
        data.NT=1;data.TIME=0;data.DISP=zeros(data.NTIME,2);
        data.PRCNT=1;
        printOUT(data,GLF,fileout,0); %PRINT the first solution
        while(data.PRCNT>data.EPSLN) 
            SOLN=GLF*GLF';
            DIFF=(GLF-data.GLU)*(GLF-data.GLU)';
            if(data.ITEM==2)
                data.GLU=data.A3*(GLF-data.GLU)-data.A4*data.GLV-data.A5*data.GLA;
                data.GLV=data.GLV+data.A1*data.GLU+data.A2*data.GLA;
                data.GLA=data.GLU;
            end
            data.GLU=GLF;
            data.DISP(data.NT,1)=data.TIME*data.SCALET;
            K=(data.NODEP-1)*data.NDF+data.NDFP;
            data.DISP(data.NT,2)=0;                                               
            data.PRCNT=sqrt(DIFF/SOLN);
            data.TIME=data.TIME+data.DT;
            %% post processing: print results
            if floor(data.NT/data.INTVL)==(data.NT/data.INTVL)
                printOUT(data,GLF,fileout,0); 
            end
    %%

            if(data.NT >= data.NTIME) 
                fid=fopen(fileout,'a');
                fprintf(fid,'\n\n     ***** Number of time steps exeeded NTIME *****');
                printOUT(data,GLF,fileout,1); 
                break
            end
            [data,GLF]= SOLVE(data,NCOUNT);
            data.NT=data.NT+1;
            
        end
        if data.PRCNT <= data.EPSLN
            fid=fopen(fileout,'a');
            fprintf(fid,'\n\n\n  **** THE SOLUTION HAS REACHED A STEADY STATE **** \n');
            printOUT(data,GLF,fileout,1); 
        end
    else
        %% post processing: print and plot results
        printOUT(data,GLF,fileout,1);  
      
    end
end

end      