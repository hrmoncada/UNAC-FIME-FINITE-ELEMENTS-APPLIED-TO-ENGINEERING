function stress=IntStress(ELU,data,ELXY)
stress=[];disp=[];
%     ________________________________________________________________
%
%     Called in printOUT to compute the derivatives of the solution for  
%     heat transfer and like problems, and stresses for fluid flow, 
%     plane elasticity and plate bending problems.
%     ________________________________________________________________
%
% %
[GAUSPT,~]=lgwt(data.ISTR,1,-1);      

if(data.IELTYP==0)%
%     Computation of the gradient/stresses at the reduced-integration
%     points of TRIANGULAR ELEMENTS:____________________________________
%
    [AL1,AL2,AL3,~] = QUADRTRI(data.NSTR,data.ISTR);
%
    for NI=1:data.NSTR
        AC1 = AL1(NI,data.ISTR);
        AC2 = AL2(NI,data.ISTR);
        AC3 = AL3(NI,data.ISTR);
        [SF,GDSF,~]=SHAPETRI(data.NPE,AC1,AC2,AC3,ELXY);
        XC= ELXY(1:data.NPE,1)'*SF(1:data.NPE)';
        YC= ELXY(1:data.NPE,2)'*SF(1:data.NPE)';
        if(data.ITYPE < 3) 
            I=1:data.NPE;
            J=data.NDF*I-1; 
            if(data.ITYPE==0);J=I;end
            UX  = ELU(J)*GDSF(1,I)';
            UY  = ELU(J)*GDSF(2,I)';
            if(data.ITYPE >= 1)
                K=J+1;
                VX  = ELU(K)*GDSF(1,I)';
                VY  = ELU(K)*GDSF(2,I)';
            end

            if(data.ITYPE==0)% Single-degree-of-freedom problems:
                SX   = -(data.A10+data.A1X*XC+data.A1Y*YC)*UX;
                SY   = -(data.A20+data.A2X*XC+data.A2Y*YC)*UY;
                VALUE= norm([SX SY]);
                if(data.IGRAD==1)
                    QX=SX;
                    QY=SY;
                else
                    QX=-SY;
                    QY= SX;
                end

                ANGLE=atand(QY/QX);
                if(isnan(ANGLE))==1; ANGLE=90;end
                    stress=[stress
                            XC,YC,QX,QY,VALUE,ANGLE];
            else
                if(data.ITYPE==1)%     Viscous incompressible flows (penalty model):---------------------
                    PRESSR = -data.PENALTY*(UX+VY);
                    STRESX = 2*data.VISCSITY*UX-data.PRESSR;
                    STRESY = 2*data.VISCSITY*VY-data.PRESSR;
                    STRSXY = data.VISCSITY*(UY+VX);
                    stress=[stress
                            XC,YC,STRESX,STRESY,STRSXY,PRESSR];
% %                     disp=[disp
% %                           XC,YC,SX,SY];
                else
        %
        %     Plane elasticity problems:----------------------------------------
        %
                    STRESX = (data.CMAT(1,1)*UX+data.CMAT(1,2)*VY)/data.THKNS;
                    STRESY = (data.CMAT(1,2)*UX+data.CMAT(2,2)*VY)/data.THKNS;
                    STRSXY = data.CMAT(3,3)*(UY+VX)/data.THKNS;
                    stress=[stress
                            XC,YC,STRESX,STRESY,STRSXY];
% %                     disp=[disp
% %                           XC,YC,SX,SY];

                end
            end
        end
    end
else
%
%     Calculation of the gradient/stresses at the reduced integration
%     gauss points of RECTANGULAR ELEMENTS:_____________________________
%
    for NI=1:data.ISTR
        for NJ=1:data.ISTR
            XI  = GAUSPT(NI);
            ETA = GAUSPT(NJ);
            [SF,GDSF,~]= SHAPERCT (data.NPE,XI,ETA,ELXY,data.NDF,data.ITYPE);
            XC=ELXY(:,1)'*SF';
            YC=ELXY(:,2)'*SF';
            if(data.ITYPE < 3)
                I=1:data.NPE;
                J=(I-1)*data.NDF+1;
                if(data.ITYPE == 0);J=I;end
                UX  = ELU(J)*GDSF(1,I)';
                UY  = ELU(J)*GDSF(2,I)';
                if(data.ITYPE >= 1)
                    K=J+1;
                    VX  = ELU(K)*GDSF(1,I)';
                    VY  = ELU(K)*GDSF(2,I)';
                end
               	if(data.ITYPE==0)% Single-degree-of-freedom problems:---
                    SX   = -(data.A10+data.A1X*XC+data.A1Y*YC)*UX;
                    SY   = -(data.A20+data.A2X*XC+data.A2Y*YC)*UY;
                    VALUE= norm([SX SY]);
                    if(data.IGRAD == 1) 
                        QX=SX;
                        QY=SY;
                    else
                        QX=-SY;
                        QY= SX;
                    end

                ANGLE=atand(QY/QX);
                if (ANGLE<0);ANGLE=ANGLE+180;end
                    stress=[stress
                            XC,YC,QX,QY,VALUE,ANGLE];
                else
                    if(data.ITYPE==1)% Viscous incompressible flows (penalty model):---------------------
                        PRESSR = -data.PENALTY*(UX+VY);
                        STRESX = 2.0*data.VISCSITY*UX-PRESSR;
                        STRESY = 2.0*data.VISCSITY*VY-PRESSR;
                        STRSXY = data.VISCSITY*(UY+VX);
                        stress=[stress
                                XC,YC,STRESX,STRESY,STRSXY,PRESSR];
                        disp=[disp
                              XC,YC,UX,VY];
                    else% Plane elasticity problems:----------------------------------------
%
                        STRESX = (data.CMAT(1,1)*UX+data.CMAT(1,2)*VY)/data.THKNS;
                        STRESY = (data.CMAT(1,2)*UX+data.CMAT(2,2)*VY)/data.THKNS;
                        STRSXY = data.CMAT(3,3)*(UY+VX)/data.THKNS;
                        stress=[stress
                                XC YC STRESX STRESY STRSXY]; 
                        disp=[disp
                              XC,YC,UX,VY];
                    end
                end
            else
%
%     Plate bending problems:-------------------------------------------
%     Stresses SGMAX, SGMAY and SGMXY are computed at the top/bottom of
%     the plate (and SGMXZ and SGMYZ are constant through thickness)
%
                PLTD=(data.THKNS*data.THKNS)/6.0D0;
                if(data.ITYPE == 3)% First-order shear deformation theory of plates:-------------------
                    I=1:NPE;
                    J=NDF*(I-1)+1;
                    K=J+1;
                    L=K+1;
                    DWX  = GDSF(1,I)*ELU(J);
                    DWY  = GDSF(2,I)*ELU(J);
                    SIX  = SF(I)*ELU(K);
                    SIY  = SF(I)*ELU(L);
                    DSXX = GDSF(1,I)*ELU(K);
                    DSXY = GDSF(2,I)*ELU(K);
                    DSYX = GDSF(1,I)*ELU(L);
                    DSYY = GDSF(2,I)*ELU(L);
                    SGMAX = (CMAT(1,1)*DSXX+CMAT(1,2)*DSYY)/PLTD;
                    SGMAY = (CMAT(1,2)*DSXX+CMAT(2,2)*DSYY)/PLTD;
                    SGMXY = CMAT(3,3)*(DSXY+DSYX)/PLTD;
                    SGMXZ = 1.2*C55*(DWX+SIX)/THKNS;
                    SGMYZ = 1.2*C44*(DWY+SIY)/THKNS;
                    stress=[stress
                            XC YC SGMAX SGMAY SGMXY]; 
                    disp=[disp
                          XC,YC,SIX,SIY];
                else% Classical theory of plates:---------------------------------------
%
                    NN=data.NPE*data.NDF;
                    DSXX = GDDSFH(1,1:NN)*ELU(1:NN)';
                    DSYY = GDDSFH(2,1:NN)*ELU(1:NN)';
                    DSXY = GDDSFH(3,1:NN)*ELU(1:NN)';
                    SGMAX =-(data.CMAT(1,1)*DSXX+data.CMAT(1,2)*DSYY)/data.PLTD;
                    SGMAY =-(data.CMAT(1,2)*DSXX+data.CMAT(2,2)*DSYY)/data.PLTD;
                    SGMXY =-4.0*data.CMAT(3,3)*DSXY/data.PLTD;
                    stress=[stress
                            XC YC SGMAX SGMAY SGMXY];
                    disp=[disp
                          XC,YC,SIX,SIY];
                end
            end
        end
    end
end
end
   
