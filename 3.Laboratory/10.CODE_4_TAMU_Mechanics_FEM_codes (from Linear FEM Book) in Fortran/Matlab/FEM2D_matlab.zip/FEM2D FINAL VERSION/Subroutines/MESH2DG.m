function [GLXY,NOD]=MESH2DG(data,fid)

%     ________________________________________________________________
%
%     Called in MAIN to generate nodal point coordinates for specified 
%     type meshes (see Fig. 13.4.2 for examples)
%
%     NOD1  = First node number in the line segment
%     NODL  = Last node number in the line segment
%     NODINC= Node increment from one node to the next along the line
%     X1,Y1 = Global coordinates of the first node on the line
%     XL,YL = Global coordinates of the last node on the line
%     RATIO = The ratio of the first element to the last element
%     _________________________________________________________________
%
    
      
GLXY(1:data.NNM,1)=1.E20;
GLXY(1:data.NNM,2)=1.E20;
%
%     Read number of the records (line segmments) and data in each line
%
nrecl=textscan(fid,'%n',1,'commentStyle', '//');NRECL=nrecl{1};

for IREC=1:NRECL
    temp=textscan(fid,'%n %n %n %n %n %n %n %n',1,'commentStyle', '//');
    NOD1=temp{1};NODL=temp{2};NODINC=temp{3};X1=temp{4};Y1=temp{5};
    XL=temp{6};YL=temp{7};RATIO=temp{8};
    if (NODL < NOD1); NODL = NOD1;end
    if(NODL~=NOD1) 
        if(NODINC <= 0); NODINC = 1;end
	    if(RATIO <= 0); RATIO=1.0;end
        NODIF = (NODL-NOD1)/NODINC;
	    XL1 = XL-X1;
        YL1=YL-Y1;
        GLXY(NOD1,1)=X1;
        GLXY(NOD1,2)=Y1;
        ALNGTH = sqrt(XL1*XL1+YL1*YL1);
	    ALINC = (2.0*ALNGTH/NODIF)*RATIO/(RATIO+1.0);
	    ALRAT = ALINC/RATIO;
	    if(NODIF~=1); DEL=(ALINC-ALRAT)/(NODIF-1);end
        if(NODIF==1); DEL=0.0;end
	    SUM=0.0;
        I=-1;
        for N=1:NODIF
            I=I+1;
            SUM=SUM+ALINC-I*DEL;
            NI=NOD1+N*NODINC;
            GLXY(NI,1)=X1+XL1*SUM/ALNGTH;
            GLXY(NI,2)=Y1+YL1*SUM/ALNGTH;
        end
    end
end
[NOD,GLXY]= CONCTVTY(data.NEM,data.NPE,GLXY,fid);  
end