function [ELK,ELM,ELF]=ELKMFTRI(data,ELXY)
%     ________________________________________________________________
%
%     Called in MAIN to compute element  matrices based on  linear and 
%     quadrati%  TRIangular elements and isoparametri% formulation for 
%     for all classes of problems of the book. Reduced  integration is
%     used on certain terms of viscous flow and plate bending problems. 
%     ________________________________________________________________
%

NDF = data.NN/data.NPE;
%
%     Call subroutine QUADRature for TRIangle to compute arrays of  
%     integration points and weights for the given NIPF and IPDF
%
[AL1,AL2,AL3,ALWT] = QUADRTRI (data.NIPF,data.IPDF);

%%     Initialize the arrays
%
ELF = zeros(1,data.NN);
ELM = zeros(data.NN);
ELK = zeros(data.NN);

%%     Do-loop on the numerical integration begins here

for NI = 1:data.NIPF
    AC1 = AL1(NI,data.IPDF);
    AC2 = AL2(NI,data.IPDF);
    AC3 = AL3(NI,data.IPDF);
    [SF,GDSF,DET]=SHAPETRI(data.NPE,AC1,AC2,AC3,ELXY);
    CNST = 0.50*DET*ALWT(NI,data.IPDF);
    X=ELXY(1:data.NPE,1)'*SF(1:data.NPE)';
    Y=ELXY(1:data.NPE,2)'*SF(1:data.NPE)';
    if(data.NEIGN == 0); SOURCE=data.F0+data.FX*X+data.FY*Y;  end
    if(data.ITEM~=0);	   CT =data.C0+data.CX*X+data.CY*Y;   end
    if(data.ITYPE <= 0) 
        A11=data.A10+data.A1X*X+data.A1Y*Y;
        A22=data.A20+data.A2X*X+data.A2Y*Y;
    end
    II=1;
    for I=1:data.NPE
        JJ=1;
        for J=1:data.NPE
            S00=SF(I)*SF(J)*CNST;
            S11=GDSF(1,I)*GDSF(1,J)*CNST;
            S22=GDSF(2,I)*GDSF(2,J)*CNST;
            S12=GDSF(1,I)*GDSF(2,J)*CNST;
            S21=GDSF(2,I)*GDSF(1,J)*CNST;
            if (data.ITYPE==0)% Heat transfer and like problems (i.e. single DOF problems):_______
                ELK(I,J) = ELK(I,J) + A11*S11 + A22*S22 + data.A00*S00;
                if(data.ITEM~=0) 
                    ELM(I,J) = ELM(I,J) + CT*S00;
                end
            else
                if(data.ITYPE==1) %     Viscous incompressible fluids:
%     Compute coefficients associated with viscous terms (full integ.)
                    ELK(II,JJ)    = ELK(II,JJ)     + data.VISCSITY*(2.0*S11 + S22);
                    ELK(II+1,JJ)  = ELK(II+1,JJ)   + data.VISCSITY*S12;
                    ELK(II,JJ+1)  = ELK(II,JJ+1)   + data.VISCSITY*S21;
                    ELK(II+1,JJ+1)= ELK(II+1,JJ+1) + data.VISCSITY*(S11 + 2.0*S22);
                    if(data.ITEM~=0) 
                        ELM(II,JJ)    = ELM(II,JJ)     + CT*S00;
                        ELM(II+1,JJ+1)= ELM(II+1,JJ+1) + CT*S00;
                    end
                else%  Plane elasticity problems:________________________________________
                    ELK(II,JJ)    = ELK(II,JJ) + data.CMAT(1,1)*S11+ data.CMAT(3,3)*S22;
                    ELK(II,JJ+1)  = ELK(II,JJ+1)  + data.CMAT(1,2)*S12 + data.CMAT(3,3)*S21;
                    ELK(II+1,JJ)  = ELK(II+1,JJ)  + data.CMAT(1,2)*S21 + data.CMAT(3,3)*S12;
                    ELK(II+1,JJ+1)= ELK(II+1,JJ+1)+ data.CMAT(3,3)*S11 + data.CMAT(2,2)*S22;
                    if(data.ITEM~=0) 
                        ELM(II,JJ)    = ELM(II,JJ)     + CT*S00;
                        ELM(II+1,JJ+1)= ELM(II+1,JJ+1) + CT*S00;
                    end
                end
            end
            JJ = data.NDF*J+1;
        end
        if (data.NEIGN==0)  % Source of the form fx = F0 + FX*X + FY*Y is assumed
            L=(I-1)*NDF+1;
            ELF(L) = ELF(L)+CNST*SF(I)*SOURCE;
        end
        II = data.NDF*I+1;
    end
end
%
if (data.ITYPE==1 || data.ITYPE==3) 
%
%     Use reduced integration to evaluate coefficients associated with
%     penalty terms for flows and transverse shear terms for plates.
%
%     Call subroutine QUADRature for TRIangles to compute arrays of integration
%     points and weights for the given NIPR and IPDR
%
    [AL1,AL2,AL3,ALWT] = QUADRTRI (data.NIPR,data.IPDR);
%
    for NI=1:data.NIPR
        AC1 = AL1(NI,data.IPDR);
        AC2 = AL2(NI,data.IPDR);
        AC3 = AL3(NI,data.IPDR);
        [SF,GDSF,DET]= SHAPETRI (data.NPE,AC1,AC2,AC3,ELXY);
        CNST = 0.50D0*DET*ALWT(NI,IPDR);
    %
        II=1;
        for I=1:data.NPE
            JJ = 1;
            for J=1:data.NPE
                S11=GDSF(1,I)*GDSF(1,J)*CNST;
                S22=GDSF(2,I)*GDSF(2,J)*CNST;
                S12=GDSF(1,I)*GDSF(2,J)*CNST;
                S21=GDSF(2,I)*GDSF(1,J)*CNST;
                if(data.ITYPE==1) %     Viscous incompressible fluids (penalty terms):____________________
                    ELK(II,JJ)    = ELK(II,JJ)     + data.PENALTY*S11;
                    ELK(II+1,JJ)  = ELK(II+1,JJ)   + data.PENALTY*S21;
                    ELK(II,JJ+1)  = ELK(II,JJ+1)   + data.PENALTY*S12;
                    ELK(II+1,JJ+1)= ELK(II+1,JJ+1) + data.PENALTY*S22;
                else %     Shear deformable plates (transverse shear terms):_________________
    %
                    S00 = SF(I)*SF(J)*CNST;
                    S10 = GDSF(1,I)*SF(J)*CNST;
                    S01 = SF(I)*GDSF(1,J)*CNST;
                    S20 = GDSF(2,I)*SF(J)*CNST;
                    S02 = SF(I)*GDSF(2,J)*CNST;
                    ELK(II,JJ)    = ELK(II,JJ)     + data.C55*S11+data.C44*S22;
                    ELK(II,JJ+1)  = ELK(II,JJ+1)   + data.C55*S10;
                    ELK(II+1,JJ)  = ELK(II+1,JJ)   + data.C55*S01;
                    ELK(II,JJ+2)  = ELK(II,JJ+2)   + data.C44*S20;
                    ELK(II+2,JJ)  = ELK(II+2,JJ)   + data.C44*S02;
                    ELK(II+1,JJ+1)= ELK(II+1,JJ+1) + data.C55*S00;
                    ELK(II+2,JJ+2)= ELK(II+2,JJ+2) + data.C44*S00;
                end
                JJ=data.NDF*J+1;
            end
            II=data.NDF*I+1;
        end
    end
end
