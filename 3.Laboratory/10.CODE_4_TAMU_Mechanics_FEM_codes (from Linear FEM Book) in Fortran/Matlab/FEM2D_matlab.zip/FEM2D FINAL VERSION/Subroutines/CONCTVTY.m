function [NODES,GLXY]= CONCTVTY(NELEM,NPE,GLXY,fid)
%     ________________________________________________________________
%
%     Generates nodal connectivity array for a specified type of mesh
%
%     NEL1    = First element in the row of elements
%     NELL    = Last element in the row
%     IELIN%  = Increment from element to the next in the row
%     NODIN%  = Node increment from one element to the next
%     NPE     = Number of nodes per element
%     NODE(I) = Global node numbers corresponding to the local nodes
%               of the first element in the row
%     ________________________________________________________________
%

%     Read element data
%

nrecel=textscan(fid,'%n',1,'commentStyle', '//');NRECEL=nrecel{1};
for IREC=1:NRECEL
    temp=textscan(fid,'%n %n %n %n %n ',1,'commentStyle', '//');
    NEL1=temp{1};NELL=temp{2};IELINC=temp{3};NODINC=temp{4};NPE=temp{5};
    temp=textscan(fid,'%n ',NPE,'commentStyle', '//');
    NODE=temp{:};
    if (IELINC <= 0); IELINC=1; end
    if (NODINC <= 0); NODINC=1; end
    if (NELL <= NEL1); NELL = NEL1; end
    if(NELL > NELEM)
        error('MSG from CNCTVT: Element number exceeds maximum value')
    else
        NINC=-1;
        for N=NEL1:IELINC:NELL
            NINC=NINC+1;
            for M=1:NPE
                NODES(N,M)=NODE(M)+NINC*NODINC;
            end
        end
    end
end

for N=1:NELEM
    SUMX=0.0;
    SUMY=0.0;
    NEN=NPE;
    if (NEN ~= 4)
        for M=5:NEN
            MM=NODES(N,M);
            if (M ~= 9 || M ~= 6) 
                M4=NODES(N,M-4);
                M3=NODES(N,M-3);
                if (M == 8); M3=NODES(N,1); end
                if(GLXY(MM,1)==1.E20);GLXY(MM,1)=0.5*(GLXY(M4,1)+GLXY(M3,1));end
                if(GLXY(MM,2)==1.E20);GLXY(MM,2)=0.5*(GLXY(M4,2)+GLXY(M3,2));end
                if(NEN~=8) 
                    SUMX=SUMX+GLXY(M4,1);
                    SUMY=SUMY+GLXY(M4,2);
                end
            else
            if(GLXY(MM,1) == 1.E20); GLXY(MM,1)=0.25*SUMX; end
	        if(GLXY(MM,2) == 1.E20); GLXY(MM,2)=0.25*SUMY; end
            end
        end
    end
end

end
     
