function[ELK,ELF]=TEMPORAL(data,ELK,ELF,ELM,ELU,ELV,ELA,NCOUNT)
%   __________________________________________________________________
% 
%    Called in SOLVE to compute the fully discretized equations for the
%    paraboli% and hyperboli% differential equations in time using the 
%    alfa-family and Newmark family of approximations, respectively.
%   __________________________________________________________________

if data.ITEM==1 % The alfa-family of time approximation for paraboli% equations
    SUM=(ELM-data.A2*ELK)*ELU';
    ELK=ELM+data.A1*ELK;
    ELF=(data.A1+data.A2)*ELF+SUM';
else %The Newmark integration scheme for hyperbolic equations
    if(NCOUNT==1 && data.INTIAL~=0)
        ELF = ELF -ELK*ELU';
        ELK = ELM;
    else
        SUM = ELM*(data.A3*ELU+data.A4*ELV+data.A5*ELA)';
        ELK = ELK + data.A3*ELM;
        ELF = ELF + SUM';
    end
end

end