function RHS= EQNSOLVR(NEQNS,NBW,BAND,RHS,IRES)
%     _________________________________________________________________
% 
%     Called in SOLVE to solve a  banded, symmetric, system of algebraic
%     equations using the Gauss elimination method:  [BAND]{U} = {RHS}.
%     The coefficient matrix is input as BAND(NEQNS,NBW) and the column
%     vector is input as  RHS(NEQNS),  where NEQNS is the actual number
%     of equations and NBW is the half band width.  The true dimensions
%     of the matrix [BAND] in the calling program, are NRM by NCM. When
%     IRES is greater than zero, the right hand elimination is skipped.
%     _________________________________________________________________


MEQNS=NEQNS-1;                                                             
if(IRES<=0)
    for NPIV=1:MEQNS                                                    
        NPIVOT=NPIV+1;                                                         
        LSTSUB=NPIV+NBW-1;                                                     
        if(LSTSUB > NEQNS);LSTSUB=NEQNS;end
%                                                                               
        for NROW=NPIVOT:LSTSUB
            NCOL=NROW-NPIV+1;                                                      
            FACTOR=BAND(NPIV,NCOL)/BAND(NPIV,1);                                   
            for NCOL=NROW:LSTSUB                                              
                ICOL=NCOL-NROW+1;                                                      
                JCOL=NCOL-NPIV+1;                                                      
                BAND(NROW,ICOL)=BAND(NROW,ICOL)-FACTOR*BAND(NPIV,JCOL);
            end
            RHS(NROW)=RHS(NROW)-FACTOR*RHS(NPIV);
        end
    end
else
    for NPIV=1:MEQNS                                                    
        NPIVOT=NPIV+1;                                                         
        LSTSUB=NPIV+NBW-1;                                                     
        if (LSTSUB > NEQNS);LSTSUB=NEQNS;end
        for NROW=NPIVOT:LSTSUB                                              
            NCOL=NROW-NPIV+1;                                                      
            FACTOR=BAND(NPIV,NCOL)/BAND(NPIV,1);                                   
            RHS(NROW)=RHS(NROW)-FACTOR*RHS(NPIV);
        end
    end
end
%
%     Back substitution                                                         
%                                                                               
for IJK=2:NEQNS                                                         
    NPIV=NEQNS-IJK+2;                                                          
    RHS(NPIV)=RHS(NPIV)/BAND(NPIV,1);                                          
    LSTSUB=NPIV-NBW+1;                                                         
    if(LSTSUB < 1);LSTSUB=1;end
    NPIVOT=NPIV-1;                                                             
    for JKI=LSTSUB:NPIVOT                                                   
        NROW=NPIVOT-JKI+LSTSUB;                                                    
        NCOL=NPIV-NROW+1;                                                          
        FACTOR=BAND(NROW,NCOL);                                                    
        RHS(NROW)=RHS(NROW)-FACTOR*RHS(NPIV);                                      
    end
end
RHS(1)=RHS(1)/BAND(1,1);                                                   
end