function [ELK,ELM,ELF]= ELKMFRCT(data,ELXY)
%     ________________________________________________________________
%
%     Called in SOLVE to compute element  matrices based on  linear and 
%     quadratic ReCTangular elements and isoparametri% formulation for 
%     for all classes of problems of the book. Reduced  integration is
%     used on certain terms of viscous flow and plate bending problems.
%     ________________________________________________________________
%

if(data.ITYPE <= 3) 
    NET=data.NPE;
else
    NET=data.NN;
end
%
%     Initialize the arrays
%
ELF=zeros(1,data.NN);
ELM=zeros(data.NN);
ELK=zeros(data.NN);
[GAUSPT,GAUSWT]=lgwt(data.IPDF,-1,1);      
%
%     Do-loops on numerical (Gauss) integration begin here. Subroutine
%     SHAPERCT (SHAPE functions for ReCTangular elements) is called here
%
for NI = 1:data.IPDF
    for NJ = 1:data.IPDF
        XI  = GAUSPT(NI);
        ETA = GAUSPT(NJ);
        [SF,GDSF,DET]= SHAPERCT (data.NPE,XI,ETA,ELXY,data.NDF,data.ITYPE);
        CNST = DET*GAUSWT(NI)*GAUSWT(NJ);
        X=ELXY(:,1)'*SF';
        Y=ELXY(:,2)'*SF';
        if(data.NEIGN==0); SOURCE=data.F0+data.FX*X+data.FY*Y;end
        if(data.ITEM~=0)
            if(data.ITYPE <= 2)
                CT=data.C0+data.CX*X+data.CY*Y;
            end
        end
        if(data.ITYPE <= 0)
            A11=data.A10+data.A1X*X+data.A1Y*Y;
            A22=data.A20+data.A2X*X+data.A2Y*Y;
        end
%
        II=1;
        for I=1:NET
            JJ=1;
            for J=1:NET
                if(data.ITYPE <= 3) 
                    S00=SF(I)*SF(J)*CNST;
                    S11=GDSF(1,I)*GDSF(1,J)*CNST;
                    S22=GDSF(2,I)*GDSF(2,J)*CNST;
                    S12=GDSF(1,I)*GDSF(2,J)*CNST;
                    S21=GDSF(2,I)*GDSF(1,J)*CNST;
                end
                if(data.ITYPE==0) % Heat transfer and like problems (i.e. single DOF problems):_______
                    ELK(I,J) = ELK(I,J) + A11*S11 + A22*S22 + data.A00*S00;
                    if(data.ITEM~=0) 
                        ELM(I,J) = ELM(I,J) +CT*S00;
                    end
                else
                    if(data.ITYPE==1) 
%
%     Viscous incompressible fluids:____________________________________
%     Compute coefficients associated with viscous terms (full integ.)
%
                        ELK(II,JJ)    = ELK(II,JJ)     + data.VISCSITY*(2*S11 + S22);
                        ELK(II+1,JJ)  = ELK(II+1,JJ)   + data.VISCSITY*S12;
                        ELK(II,JJ+1)  = ELK(II,JJ+1)   + data.VISCSITY*S21;
                        ELK(II+1,JJ+1)= ELK(II+1,JJ+1) + data.VISCSITY*(S11 + 2*S22);
                        if(data.ITEM~=0) 
                            ELM(II,JJ)    = ELM(II,JJ)     + CT*S00;
                            ELM(II+1,JJ+1)= ELM(II+1,JJ+1) + CT*S00;
                        end
                    else
                        if(data.ITYPE==2) 
        %
        %     Plane elasticity problems:________________________________________
        %
                            ELK(II,JJ)    =ELK(II,JJ)    +data.CMAT(1,1)*S11+data.CMAT(3,3)*S22;
                            ELK(II,JJ+1)  =ELK(II,JJ+1)  +data.CMAT(1,2)*S12+data.CMAT(3,3)*S21;
                            ELK(II+1,JJ)  =ELK(II+1,JJ)  +data.CMAT(1,2)*S21+data.CMAT(3,3)*S12;
                            ELK(II+1,JJ+1)=ELK(II+1,JJ+1)+data.CMAT(3,3)*S11+data.CMAT(2,2)*S22;
                            if(data.ITEM~=0)
                                ELM(II,JJ)    = ELM(II,JJ)     + CT*S00;
                                ELM(II+1,JJ+1)= ELM(II+1,JJ+1) + CT*S00;
                            end
                        else
                            if(data.ITYPE >= 4)
%
%     Classical plate theory:___________________________________________
%
                                BM1=data.CMAT(1,1)*GDDSFH(1,J)+data.CMAT(1,2)*GDDSFH(2,J);
                                BM2=data.CMAT(1,2)*GDDSFH(1,J)+data.CMAT(2,2)*GDDSFH(2,J);
                                BM6=2.0*data.CMAT(3,3)*GDDSFH(3,J);
                                ELK(I,J)=ELK(I,J)+CNST*(GDDSFH(1,I)*BM1+GDDSFH(2,I)*BM2+2.0*GDDSFH(3,I)*BM6);
                                if(data.ITEM~=0) 
                                    S00=SFH(I)*SFH(J)*CNST;
                                    SXX=GDSFH(1,I)*GDSFH(1,J)*CNST;
                                    SYY=GDSFH(2,I)*GDSFH(2,J)*CNST;
                                    if(data.NEIGN <= 1) 
                                        ELM(I,J)=ELM(I,J) + C0*S00+CX*SXX+CY*SYY;
                                    else
                                        SXY=GDSFH(1,I)*GDSFH(2,J)*CNST;
                                        SYX=GDSFH(2,I)*GDSFH(1,J)*CNST;
                                        ELM(I,J)=ELM(I,J) + data.C0*SXX + data.CX*SYY + data.CY*(SXY + SYX);
                                    end
                                end
                            else
%
%     Shear deformable plate theory:____________________________________
%
                                ELK(II+1,JJ+1)= ELK(II+1,JJ+1) + data.CMAT(1,1)*S11+data.CMAT(3,3)*S22;
                                ELK(II+1,JJ+2)= ELK(II+1,JJ+2) + data.CMAT(1,2)*S12+data.CMAT(3,3)*S21;
                                ELK(II+2,JJ+1)= ELK(II+2,JJ+1) + data.CMAT(3,3)*S12+data.CMAT(1,2)*S21;
                                ELK(II+2,JJ+2)= ELK(II+2,JJ+2) + data.CMAT(3,3)*S11+data.CMAT(2,2)*S22;
                                if (data.ITEM ~= 0) 
                                    if(data.NEIGN <= 1)
                                        ELM(II,JJ)    = ELM(II,JJ)     + C0*S00;
                                        ELM(II+1,JJ+1)= ELM(II+1,JJ+1) + CX*S00;
                                        ELM(II+2,JJ+2)= ELM(II+2,JJ+2) + CY*S00;
                                    else
                                        ELM(II,JJ)    = ELM(II,JJ)+data.C0*S11+data.CX*S22+data.CY*(S12+S21);
                                    end
                                end
                            end
                        end
                    end
                end
                JJ = data.NDF*J+1;
            end
            if(data.NEIGN==0) % Source of the form fx = F0 + FX*X + FY*Y is assumed
                if(data.ITYPE <= 3) 
                    L=(I-1)*data.NDF+1;
                    ELF(L) = ELF(L)+CNST*SF(I)*SOURCE;
                else
                    ELF(I) = ELF(I)+CNST*SFH(I)*SOURCE;
                end
            end
            II = data.NDF*I+1;
        end
    end
end
  
%
if(data.ITYPE == 1 || data.ITYPE == 3) 
%
%     Use reduced integration to evaluate coefficients associated with
%     penalty terms for flows and transverse shear terms for plates.


%% 
data.IPDR=data.IPDF;
    for NI=1:data.IPDR
        for NJ=1:data.IPDR
            XI  = GAUSPT(NI);
            ETA = GAUSPT(NJ);
            [SF,GDSF,DET]= SHAPERCT (data.NPE,XI,ETA,ELXY,data.NDF,data.ITYPE);
            CNST=DET*GAUSWT(NI)*GAUSWT(NJ);
    %
            II=1;
            for I=1:data.NPE
                JJ = 1;
                for J=1:data.NPE
                    S11=GDSF(1,I)*GDSF(1,J)*CNST;
                    S22=GDSF(2,I)*GDSF(2,J)*CNST;
                    S12=GDSF(1,I)*GDSF(2,J)*CNST;
                    S21=GDSF(2,I)*GDSF(1,J)*CNST;
                    if (data.ITYPE==1) 
    %
    %     Viscous incompressible fluids (penalty terms):____________________
    %
                        ELK(II,JJ)    = ELK(II,JJ)     + data.PENALTY*S11;
                        ELK(II+1,JJ)  = ELK(II+1,JJ)   + data.PENALTY*S21;
                        ELK(II,JJ+1)  = ELK(II,JJ+1)   + data.PENALTY*S12;
                        ELK(II+1,JJ+1)= ELK(II+1,JJ+1) + data.PENALTY*S22;
                    else
    %
    %     Shear deformable plates (transverse shear terms):_________________
    %
                        S00 = SF(I)*SF(J)*CNST;
                        S10 = GDSF(1,I)*SF(J)*CNST;
                        S01 = SF(I)*GDSF(1,J)*CNST;
                        S20 = GDSF(2,I)*SF(J)*CNST;
                        S02 = SF(I)*GDSF(2,J)*CNST;
                        ELK(II,JJ)    = ELK(II,JJ)     + C55*S11+C44*S22;
                        ELK(II,JJ+1)  = ELK(II,JJ+1)   + C55*S10;
                        ELK(II+1,JJ)  = ELK(II+1,JJ)   + C55*S01;
                        ELK(II,JJ+2)  = ELK(II,JJ+2)   + C44*S20;
                        ELK(II+2,JJ)  = ELK(II+2,JJ)   + C44*S02;
                        ELK(II+1,JJ+1)= ELK(II+1,JJ+1) + C55*S00;
                        ELK(II+2,JJ+2)= ELK(II+2,JJ+2) + C44*S00;
                    end
                    JJ=data.NDF*J+1;
                end
                II=data.NDF*I+1;
            end
        end
    end
end
end
        
