function[GLK,GLM,NEQR]=EGNBNDRY(data,GLK,GLM)   
%     ________________________________________________________________
%
%     Imposes specified homogeneous boundary conditions on the primary
%     variables  by  eliminating rows and columns corresponding to the
%     specified degrees of freedom
%     ________________________________________________________________
%

IBDY=sort((data.ISPV(1:data.NSPV,1)-1)*data.NDF+data.ISPV(1:data.NSPV,2),'descend');

NEQR = data.NEQ;
for I=1:data.NSPV
    IB=IBDY(I);
    if(IB < NEQR) 
        NEQR1=NEQR-1;
        for II=IB:NEQR1
            for JJ=1:NEQR
                GLM(II,JJ)=GLM(II+1,JJ);
                GLK(II,JJ)=GLK(II+1,JJ);
            end
            for JJ=1:NEQR
                GLM(JJ,II)=GLM(JJ,II+1);
                GLK(JJ,II)=GLK(JJ,II+1);
            end
        end
    end
    NEQR=NEQR-1;
end
