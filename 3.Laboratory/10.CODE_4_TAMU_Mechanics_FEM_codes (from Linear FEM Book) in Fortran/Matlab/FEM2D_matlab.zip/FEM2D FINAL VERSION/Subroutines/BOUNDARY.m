function[data,S,SL]=BOUNDARY(data,S,SL)
%     ________________________________________________________________
%
%     Called in SOLVE to implement specified values of the primary and
%     secondary variables by modifying the coefficient matrix [S] and
%     (banded and symmetric) and the right-hand side vector {SL}.
%     ________________________________________________________________
%

% % % % % %
if(data.NSSV ~= 0)
    if(data.INTIAL == 0 || data.NCOUNT ~= 1)
%
%     Implement specified values of the SECONDARY VARIABLES:____________
%
        for I=1:data.NSSV
            II=(data.ISSV(I,1)-1)*data.NDF+data.ISSV(I,2);
            SL(II)=SL(II)+data.VSSV(I);
        end
    end
end
%
%     Implement specified values of the PRIMARY VARIABLES:______________
%
if(data.NSPV~=0)
    for NB=1:data.NSPV
        IE = (data.ISPV(NB,1)-1)*data.NDF+data.ISPV(NB,2);
        VALUE = data.VSPV(NB);
        IT = data.NHBW-1;
        I = IE-data.NHBW;
        for II=1:IT
            I=I+1;
            if(I >= 1)
                J=IE-I+1;
                SL(I)=SL(I)-S(I,J)*VALUE;
                S(I,J)=0.0;
            end
        end
        S(IE,1)=1;
        SL(IE)=VALUE;
        I=IE;
        for II=2:data.NHBW
            I=I+1;
            if(I <= data.NEQ)
                SL(I)=SL(I)-S(IE,II)*VALUE;
                S(IE,II)=0.0;
            end
        end
    end
end
end
