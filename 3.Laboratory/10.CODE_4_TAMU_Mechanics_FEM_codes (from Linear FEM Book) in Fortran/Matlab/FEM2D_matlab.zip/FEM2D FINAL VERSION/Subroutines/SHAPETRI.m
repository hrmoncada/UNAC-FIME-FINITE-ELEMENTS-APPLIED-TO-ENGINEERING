function [SF,GDSF,DET]=SHAPETRI(NPE,AL1,AL2,AL3,ELXY)
%   ________________________________________________________________
%
%   Called in  ELKMFTRI and in IntStress to evaluate the interpolation 
%   functions and their global derivatives at the quadrature points for the 
%   linear and quadratic (i.e., 3-node and 6-node) triangular elements.
%   ________________________________________________________________
%

%     Initialize the arrays
DSF=zeros(3,NPE);

if(NPE==3) %Linear Lagrane interpolation for three-node element

    SF(1) =  AL1;
	SF(2) =  AL2;
	SF(3) =  AL3;
	DSF(1,1) = 1;
	DSF(2,2) = 1;
	DSF(3,3) = 1;
else %     Quadrati% Lagrange interpolation functions for six-nde element
    SF(1) = AL1 * (2 * AL1 - 1);
    SF(2) = AL2 * (2 * AL2 - 1);
	SF(3) = AL3 * (2 * AL3 - 1);
	SF(4) = 4 * AL1 * AL2;
	SF(5) = 4 * AL2 * AL3;
	SF(6) = 4 * AL3 * AL1;
	DSF(1,1) = 4 * AL1 - 1;
	DSF(2,2) = 4 * AL2 - 1;
	DSF(3,3) = 4 * AL3 - 1;
	DSF(1,4) = 4 * AL2;
	DSF(2,4) = 4 * AL1;
	DSF(2,5) = 4 * AL3;
	DSF(3,5) = 4 * AL2;
	DSF(1,6) = 4 * AL3;
	DSF(3,6) = 4 * AL1;
end

%     Compute the global derivatives of SF(I).  Note that the special
%     form of the jacobian for area coordinates,  AL3 = 1-AL1-AL2  is
%     substituted

GJ = [sum((DSF(1,1:NPE)-DSF(3,1:NPE))*ELXY(1:NPE,1)) sum((DSF(1,1:NPE)-DSF(3,1:NPE))*ELXY(1:NPE,2))
      sum((DSF(2,1:NPE)-DSF(3,1:NPE))*ELXY(1:NPE,1)) sum((DSF(2,1:NPE)-DSF(3,1:NPE))*ELXY(1:NPE,2))];
DET=det(GJ);
GJINV = inv(GJ);
GDSF=zeros(2,NPE);
for i=1:2
    for j=1:NPE
        GDSF(i,j)=sum(GJINV(i,1:2)*(DSF(1:2,j) - DSF(3,j)));
    end
end


end



      


      