function [GLXY,NEM,NNM,NOD]=MESH2DR(data)
%     ________________________________________________________________
%
%     Called in  INPUT to compute arrays [NOD] & [GLXY] for rectangular
%     domains. The domain is divided  into  NX  subdivisions along the
%     x-direction and NY subdivisions in the y-direction. The subdivi-
%     sions  define  rectangular elements of the type required.  For a
%     triangular element mesh, the subdivision defines two linear ele-
%     ments per a rectangular element with their common diagonal being 
%     inclined to the right (see Fig. 13.4.1 of the text).
%     ________________________________________________________________
%
%
NEX1 = data.NX+1;
NEY1 = data.NY+1;
NXX  = data.IEL*data.NX;
NYY  = data.IEL*data.NY;
NXX1 = NXX + 1;
NYY1 = NYY + 1;
NEM  = data.NX*data.NY;
if(data.IELTYP==0);NEM=2*data.NX*data.NY;end
NNM=NXX1*NYY1;
if(data.NPE==8);NNM = NXX1*NYY1 - data.NX*data.NY;end
if(data.IELTYP==0)
%
%     Generate the array [NOD]:_________________________________________
%     TRIANGULAR ELEMENTS
%
    NX2=2*data.NX;
% % 	NY2=2*data.NY;
	NOD(1,1) = 1;
	NOD(1,2) = data.IEL+1;
	NOD(1,3) = data.IEL*NXX1+data.IEL+1;
    if(data.NPE > 3) 
        NOD(1,4) = 2;
	    NOD(1,5) = NXX1 + 3;
        NOD(1,6) = NXX1 + 2;
    end
	NOD(2,1) = 1;
	NOD(2,2) = NOD(1,3);
	NOD(2,3) = data.IEL*NXX1+1;
    if(data.NPE > 3)
        NOD(2,4) = NOD(1,6);
	    NOD(2,5) = NOD(1,3) - 1;
	    NOD(2,6) = NOD(2,4) - 1;
    end
    K=3;
    for IY=1:data.NY
        L=IY*NX2;
        M=(IY-1)*NX2;
        if(data.NX > 1)
            for N=K:2:L
                for I=1:data.NPE
                    NOD(N,I)  = NOD(N-2,I)+data.IEL;
                    NOD(N+1,I)= NOD(N-1,I)+data.IEL;
                end
            end
        end
        if(IY < data.NY) 
            for I=1:data.NPE
                NOD(L+1,I)=NOD(M+1,I)+data.IEL*NXX1;
                NOD(L+2,I)=NOD(M+2,I)+data.IEL*NXX1;
            end
        end
        K=L+3;
    end
else% RECTANGULAR ELEMENTS

    K0 = 0;
	if(data.NPE == 9);K0=1;end
    NOD(1,1) = 1;
    NOD(1,2) = data.IEL+1;
    NOD(1,3) = NXX1+(data.IEL-1)*NEX1+data.IEL+1;
	if(data.NPE == 9); NOD(1,3)=4*data.NX+5;end
    NOD(1,4) = NOD(1,3) - data.IEL;
    if(data.NPE > 4) 
        NOD(1,5) = 2;
        NOD(1,6) = NXX1 + (data.NPE-6);
        NOD(1,7) = NOD(1,3) - 1;
        NOD(1,8) = NXX1+1;
        if(data.NPE == 9);NOD(1,9)=NXX1+2;end
    end
    if(data.NY > 1) 
        M = 1;
        for N = 2:data.NY
            L = (N-1)*data.NX + 1;
            for I = 1:data.NPE
                NOD(L,I) = NOD(M,I)+NXX1+(data.IEL-1)*NEX1+K0*data.NX;
            end
            M=L;
        end
    end
%
    if(data.NX > 1) 
        for NI = 2:data.NX
            for I = 1:data.NPE
                K1 = data.IEL;
                if(I == 6 || I == 8);K1=1+K0;end
                NOD(NI,I) = NOD(NI-1,I)+K1;
            end
            M = NI;
            for NJ = 2:data.NY
                L = (NJ-1)*data.NX+NI;
                for J = 1:data.NPE
                    NOD(L,J) = NOD(M,J)+NXX1+(data.IEL-1)*NEX1+K0*data.NX;
                end
                M = L;
            end
        end
    end
end
%     Generate the global coordinates of the nodes, [GLXY]:_____________
%
data.DX(NEX1)=0;
data.DY(NEY1)=0;
XC=data.X0;
YC=data.Y0;
if(data.NPE == 8) 
    for NI = 1:NEY1
        I = (NXX1+NEX1)*(NI-1)+1;
% %         J = 2*NI-1;
        GLXY(I,1) = XC;
        GLXY(I,2) = YC;
        for NJ = 1:data.NX
            DELX=0.5*data.DX(NJ);
            I=I+1;
            GLXY(I,1) = GLXY(I-1,1)+DELX;
            GLXY(I,2) = YC;
            I=I+1;
            GLXY(I,1) = GLXY(I-1,1)+DELX;
            GLXY(I,2) = YC;
        end
        if(NI <= data.NY) 
            I = I+1;
            YC= YC+0.5*data.DY(NI);
            GLXY(I,1) = XC;
            GLXY(I,2) = YC;
            for II = 1:data.NX
                I = I+1;
                GLXY(I,1) = GLXY(I-1,1)+data.DX(II);
                GLXY(I,2) = YC;
            end
        end
        YC = YC+0.5*data.DY(NI);
    end
else
    YC=data.Y0;
    for NI = 1: NEY1
        XC = data.X0;
        I = NXX1*data.IEL*(NI-1);
        for NJ = 1:NEX1
            I=I+1;
            GLXY(I,1) = XC;
            GLXY(I,2) = YC;
            if(NJ < NEX1) 
                if(data.IEL == 2) 
                    I=I+1;
                    XC = XC + 0.5*data.DX(NJ);
                    GLXY(I,1) = XC;
                    GLXY(I,2) = YC;
                end
            end
            XC = XC + data.DX(NJ)/data.IEL;
        end
        XC = data.X0;
        if(data.IEL == 2)
            YC = YC + 0.5*data.DY(NI);
            for NJ = 1:NEX1
                I=I+1;
                GLXY(I,1) = XC;
                GLXY(I,2) = YC;
                if(NJ < NEX1) 
                    I=I+1;
                    XC = XC + 0.5*data.DX(NJ);
                    GLXY(I,1) = XC;
                    GLXY(I,2) = YC;
                end
                XC = XC + 0.5*data.DX(NJ);
            end
        end
        YC = YC + data.DY(NI)/data.IEL;
    end
end
end