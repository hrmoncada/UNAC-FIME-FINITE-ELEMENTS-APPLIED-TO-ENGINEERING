function printOUT(data,GLU,fileout,PRINT)
%
%     Print and eventually plot the solution 
%     (i.e., nodal values of the primary variables)
% 

fid=fopen(fileout,'a');
if(data.ITEM~=0)
     fprintf(fid,'\n\n TIME = %8.4e, TIme step number = %d , Difference =   %d \n',[data.TIME data.NT data.PRCNT]);
end
fprintf(fid,'                  ********** SOLUTION: **********\n');
if(data.NDF <= 3) 
    MDF=data.NDF;
else
    MDF=3;
    fprintf(fid,'\n     Nodal valuee of W,xy for conforming plate element:\n');
    fprintf(fid,'%14.5e %14.5e %14.5e %14.5e %14.5e \n',data.GLU(data.NDF:data.NEQ:data.NDF));		        
end
if(data.ITYPE <= 2)
    fprintf(fid,'  _________________________________________________________________\n');
else
    fprintf(fid,'  ______________________________________________________________________________\n');
end
switch data.NDF
    case 1
        fprintf(fid,'\n   Node       x-coord.          y-coord.      Primary DOF\n');
    case 2
        fprintf(fid,'\n   Node    x-coord.      y-coord.      value of u     value of v\n');
    case 3
        fprintf(fid,'\n   Node       x-coord.          y-coord.      deflec. w\n');
end
if(data.ITYPE <= 2)
    fprintf(fid,'  _________________________________________________________________\n');
else
    fprintf(fid,'  ______________________________________________________________________________\n');
end
II=data.NDF*((1:data.NNM)-1)+1;

if data.NDF==1
    fprintf(fid,'    %2d    %14.5e    %14.5e %14.5e \n',[II',data.GLXY(1:data.NNM,1:2),GLU(II)']');	
    if (data.PLOT==1 && PRINT==1)
        x=data.GLXY(1:data.NNM,1);
        y=data.GLXY(1:data.NNM,2);
        z=GLU(II);
        [X,Y]=meshgrid(min(x):(max(x)-min(x))/100:max(x),min(y):(max(y)-min(y))/100:max(y));
        Z=griddata(x,y,z,X,Y);
        contourf(X,Y,Z);colorbar;
    end
else
    JJ=II+MDF-1;
    fprintf(fid,'   %2d %14.5e %14.5e %14.5e %14.5e \n',[(1:data.NNM)',data.GLXY(1:data.NNM,1:2),GLU(II)' , GLU(JJ)']');	
    if (data.PLOT==1 && PRINT==1)
        figure(1)    
        x=data.GLXY(1:data.NNM,1);
        y=data.GLXY(1:data.NNM,2);
        u=GLU(II);
        v=GLU(JJ);
        [X,Y]=meshgrid(min(x):(max(x)-min(x))/100:max(x),min(y):(max(y)-min(y))/100:max(y));
        U=griddata(x,y,u,X,Y);
        V=griddata(x,y,v,X,Y);
        tab1 = uitab('Title','u-value');
        ax1=axes(tab1);
        contourf(X,Y,U);colorbar;
        tab2 = uitab('Title','v-value');
        ax2=axes(tab2);
        contourf(X,Y,V);colorbar;
    end
end

fprintf(fid,'  _________________________________________________________________\n');

%%     *             P O S T P R O C E S S O R   U N I T             *
if (data.IGRAD~=0) 
    stress=[];disp=[];
    if(data.ITYPE <=1 ) 
        fprintf(fid,'  ______________________________________________________________________________\n');
    else
        fprintf(fid,'  ____________________________________________________________________\n');
    end
    if(data.ITYPE<=0) 
        fprintf(fid,'     The orientation of  gradient vector is measured from the positive x-axis \n\n');
        if(data.IGRAD==1) 
            fprintf(fid,'    x-coord.      y-coord.     -a11(du/dx)   -a22(du/dy)   Flux Mgntd   Orientation ');  
        else
            fprintf(fid,'    x-coord.      y-coord.      a22(du/dy)   -a11(du/dx)   Flux Mgntd   Orientation ');
        end
    else
        if(data.ITYPE == 1)
            fprintf(fid,'\n    x-coord.      y-coord.      sigma-x       sigma-y     sigma-xy     pressure ');
%             stress=[];
        end
        if(data.ITYPE >= 2)
             fprintf(fid,'\n     x-coord.     y-coord.      sigma-x       sigma-y       sigma-xy ');
        end
        if(data.ITYPE == 3)
            fprintf(fid,'                                                             sigma-xz     sigma-yz');
        end
    end
    if(data.ITYPE<=1)
        fprintf(fid,'\n  ___________________________________________________________________________________\n');
    else
        fprintf(fid,'\n  ____________________________________________________________________\n');
    end
%
%     Compute the GRADIENT of the solution for single-variable problems
%     or STRESSES for viscous flows, plane elasticity and plate bending
%
ELXY=zeros(9,2);
    for N=1:data.NEM
        for I=1:data.NPE
            NI=data.NOD(N,I);
            ELXY(I,1)=data.GLXY(NI,1);
            ELXY(I,2)=data.GLXY(NI,2);
            LI=(NI-1)*data.NDF;
            L=(I-1)*data.NDF;
            for J=1:data.NDF
                LI=LI+1;
                L=L+1;
                ELU(L)=GLU(LI);
            end
        end
        STRESS=IntStress(ELU,data,ELXY); %it replaces POSTPROC
        stress=[stress
                STRESS];
        
    end
    switch size(stress,2)
        case 5 
            fprintf(fid,' %13.5e %13.5e %13.5e %13.5e %13.5e   \n',stress');
        case 6 
            fprintf(fid,' %13.5e %13.5e %13.5e %13.5e %13.5e   %2.2f \n',stress');
    end         
    if(data.ITYPE <= 1)
        fprintf(fid,'  ___________________________________________________________________________________\n\n');
    else
        fprintf(fid,'  _____________________________________________________________________\n\n');
    end
    if (data.PLOT==1 && PRINT==1)
        x=stress(:,1);
        y=stress(:,2);
        [X,Y]=meshgrid(min(x):(max(x)-min(x))/50:max(x),min(y):(max(y)-min(y))/50:max(y));
        if(data.ITYPE==0)% Single-degree-of-freedom problems:
            sx=stress(:,3);
            sy=stress(:,4);
            value=stress(:,5);
            SX=griddata(x,y,sx,X,Y);
            SY=griddata(x,y,sy,X,Y);
            VALUE=griddata(x,y,value,X,Y);
            figure(2)
            contourf(X,Y,VALUE)
            hold on
            quiver(X,Y,SX,SY,'-k')
            hold off
    %         set(gca,'XTick',0.1:0.2:1,'XTickLabel',0.1:0.2:1)
        else
            sigx=stress(:,3);
            sigy=stress(:,4);
            sigxy=stress(:,5);
            SIGX=griddata(x,y,sigx,X,Y);
            SIGY=griddata(x,y,sigy,X,Y);
            SIGXY=griddata(x,y,sigxy,X,Y);
            if(data.ITYPE==1)%     Viscous incompressible flows (penalty model):--------------------
                pressure=stress(:,6);
                PRESSURE=griddata(x,y,pressure,X,Y);
                figure(2)
                tab1 = uitab('Title','sigma-x');
                ax1=axes(tab1);
                contourf(X,Y,SIGX);colorbar;
                tab2 = uitab('Title','sigma-y');
                ax2=axes(tab2);
                contourf(X,Y,SIGY);colorbar;
                tab3 = uitab('Title','sigma-xy');
                ax3=axes(tab3);
                contourf(X,Y,SIGXY);colorbar;
                tab4 = uitab('Title','PRESSURE');
                ax4=axes(tab4);
                contourf(X,Y,PRESSURE);colorbar;
            else %     Plane elasticity problems:----------------------------------------
                figure(2)
                tab1 = uitab('Title','sigma-x');
                ax1=axes(tab1);
                contourf(X,Y,SIGX);colorbar;
                tab2 = uitab('Title','sigma-y');
                ax2=axes(tab2);
                contourf(X,Y,SIGY);colorbar;
                tab3 = uitab('Title','sigma-xy');
                ax3=axes(tab3);
                contourf(X,Y,SIGXY);colorbar;
            end
        end
    end
end


end