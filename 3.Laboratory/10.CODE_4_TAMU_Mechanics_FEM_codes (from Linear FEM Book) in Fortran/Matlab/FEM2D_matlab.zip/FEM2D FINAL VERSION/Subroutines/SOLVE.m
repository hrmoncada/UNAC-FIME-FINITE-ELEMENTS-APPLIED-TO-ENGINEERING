function [data,GLF]= SOLVE(data,NCOUNT,fileout)

if(data.ITEM~=0 && data.NEIGN == 0)
    if(NCOUNT >= data.NSTP) 
        data.F0=0.0;
	    data.FX=0.0;
	    data.FY=0.0;
    end
end
%
%     Initialize the global coefficient matrices and vectors
%
GLF=zeros(1,data.NEQ);GLM=zeros(data.NEQ,data.NHBW);GLK=zeros(data.NEQ,data.NHBW);
ELXY=zeros(9,2);
%
%     Do-loop on the number of ELEMENTS to compute element matrices
%     and their assembly begins here
%
for N=1:data.NEM
    for I=1:data.NPE
        NI=data.NOD(N,I);
        ELXY(I,1)=data.GLXY(NI,1);
        ELXY(I,2)=data.GLXY(NI,2);
        if(data.NEIGN==0) 
            if(data.ITEM~=0)
                LI=(NI-1)*data.NDF;
                L = (I-1)*data.NDF;
                for J=1:data.NDF
                    LI=LI+1;
                    L=L+1;
                    ELU(L)=data.GLU(LI);
                    if(data.ITEM==2)
                        ELV(L)=data.GLV(LI);
                        ELA(L)=data.GLA(LI);
                    else
                        ELV(L)=0;
                        ELA(L)=0;
                    end
                end
            end
        end
    end
%%
%     Call subroutine ELKMFTRI (for Triangular elements) or ELKMFRCT (for
%     Rectangular elements) to compute the ELement [K], [M] and {F}.
%
    if(data.IELTYP==0) 
	    [ELK,ELM,ELF]=ELKMFTRI(data,ELXY); 
    else
	   [ELK,ELM,ELF]= ELKMFRCT (data,ELXY);
    end
%
    if(data.ICONV~=0)
%
%     Add the convective terms for CONVECTION type boundary conditions
%     (exact for straight sided elements; otherwise approximate values)
%
        for M = 1:data.NBE
            if(data.IBN(M)==N) 
                M1  = data.INOD(M,1);
                M2  = data.INOD(M,2);
                NM1 = data.NOD(N,M1);
                NM2 = data.NOD(N,M2);
                DL  = norm(data.GLXY(NM2,1:2)-data.GLXY(NM1,1:2));
                BL  = data.BETA(M)*DL;
                TF  = data.TINF(M)*BL;
                if(data.IEL==1)
                    ELK(M1,M1)=ELK(M1,M1)+BL/3;
                    ELK(M1,M2)=ELK(M1,M2)+BL/6;
                    ELK(M2,M1)=ELK(M2,M1)+BL/6;
                    ELK(M2,M2)=ELK(M2,M2)+BL/3;
                    ELF(M1)=ELF(M1)+0.5*TF;
                    ELF(M2)=ELF(M2)+0.5*TF;
                else
                    if(data.NPE >= 8)
                        NPEL=4;
                    else
                        NPEL=3;
                    end
                    M3=M1+NPEL;
                    ELK(M1,M1)=ELK(M1,M1)+4*BL/30;
                    ELK(M1,M3)=ELK(M1,M3)+2*BL/30;
                    ELK(M1,M2)=ELK(M1,M2)-BL/30;
                    ELK(M3,M1)=ELK(M3,M1)+2*BL/30;
                    ELK(M3,M3)=ELK(M3,M3)+16*BL/30;
                    ELK(M2,M3)=ELK(M2,M3)+2*BL/30;
                    ELK(M2,M1)=ELK(M2,M1)-BL/30;
                    ELK(M3,M2)=ELK(M3,M2)+2*BL/30;
                    ELK(M2,M2)=ELK(M2,M2)+4*BL/30;
                    ELF(M1)=ELF(M1)+TF/6;
                    ELF(M3)=ELF(M3)+4*TF/6;
                    ELF(M2)=ELF(M2)+TF/6;
                end
            end
        end
    end

%
    if(NCOUNT==1)
        if(data.NPRNT==1 || data.NPRNT==3) 
            if(N==1) 
%
%     Print element matrices and vectors (only when NPRNT=1 or NPRNT=3)
%
% % 		     WRITE(ITT,610)
                for I=1:data.NN
% %                     WRITE(ITT,930) (ELK(I,J),J=1,NN)
                end
                if(data.NEIGN==0) 
% %     		        WRITE(ITT,630)
% %         	        WRITE(ITT,930) (ELF(I),I=1,NN)
                else
%                     WRITE(ITT,620)
                    for I=1:data.NN
%                         WRITE(ITT,930) (ELM(I,J),J=1,NN)
                    end
                end
            end
        end
    end
%
    if(data.NEIGN==0)
        if(data.ITEM~=0) 
%
%     Compute the element coefficient matrices [K-hat] and {F-hat}
%     (i.e., after time approximation) in the transient analysis:_______
%
            [ELK,ELF]=TEMPORAL(data,ELK,ELF,ELM,ELU,ELV,ELA,NCOUNT);
        end
    end
%
%     ASSEMBLE element matrices to obtain global matrices:______________
%
    for I=1:data.NPE
        NR=(data.NOD(N,I)-1)*data.NDF;
        for II=1:data.NDF
            NR=NR+1;
            L=(I-1)*data.NDF+II;
            if(data.NEIGN==0);GLF(NR)=GLF(NR)+ELF(L);end
            for J=1:data.NPE
                if(data.NEIGN==0)
                    NCL=(data.NOD(N,J)-1)*data.NDF;
                else
                    NC=(data.NOD(N,J)-1)*data.NDF;
                end
                for JJ=1:data.NDF
                    M=(J-1)*data.NDF+JJ;
                    if(data.NEIGN==0)
                        NC=NCL+JJ+1-NR;
                        if(NC > 0);GLK(NR,NC)=GLK(NR,NC)+ELK(L,M);end
                    else
                        NC=NC+1;
                        GLK(NR,NC)=GLK(NR,NC)+ELK(L,M);
                        GLM(NR,NC)=GLM(NR,NC)+ELM(L,M);
                    end
                end
            end
        end
    end
end
       
%%
%     Print global matrices when NPRNT > 2
%
if(NCOUNT <= 1)
    if(data.NPRNT >= 2) 
%         WRITE(ITT,640)
        for I=1:data.NEQ
%             WRITE(ITT,930) (GLK(I,J),J=1,NHBW)
        end
        if(data.NEIGN==0)
%             WRITE(ITT,650)
%             WRITE(ITT,930) (GLF(I),I=1,NEQ)
        else
%             WRITE(ITT,655)
            for I=1:data.NEQ
%                 WRITE(ITT,930) (GLM(I,J),J=1,NEQ)
            end
        end
    end
end
%
%     Impose BOUNDARY CONDITIONS on primary and secondary variables
%
if(data.NEIGN~=0)
    [GLK,GLM,NEQR]=EGNBNDRY(data,GLK,GLM);   
%
%     Call subroutine EGNSOLVR to solve for eigenvalues and eigenvectors
%     and print them as specified
%
    [EGNVEC,EGNVAL]=eig(GLK(1:NEQR,1:NEQR),GLM(1:NEQR,1:NEQR));%EU: 
    fid=fopen(fileout,'a');
    fprintf(fid,'\n  ********** SOLUTION: **********\n');
   if(data.ITEM >= 2 && data.NEIGN==1)
        fprintf(fid,'\n    EIGENVALUES     SQRT(EGNVAL)\n');
        fprintf(fid,'%15.5e %15.5e \n',diag(EGNVAL)',sqrt(diag(EGNVAL))');
   else
        fprintf(fid,'\n          EIGENVALUES:\n');
        fprintf(fid,'      %15.5e \n',diag(EGNVAL)');
    end
    
    if(data.NVCTR~=0)
        for i=1:NEQR
            fprintf(fid,'\n EIGENVECTORS %d : ',i);
            fprintf(fid,'%15.5e',EGNVEC(:,i));
        end
    end
    
else
    [data,GLK,GLF]=BOUNDARY(data,GLK,GLF);
    if (NCOUNT <= 1)
        if(data.NPRNT >= 2)
% %             WRITE(ITT,650)
% %             WRITE(ITT,930) (GLF(I),I=1,NEQ)
        end
    end
%
%     Call subroutine  EQNSOLVR  to solve the system of algebrai% equations
%     The solution is returned in the array GLF
%
    IRES=0;
	GLF= EQNSOLVR(data.NEQ,data.NHBW,GLK,GLF,IRES);
end

end