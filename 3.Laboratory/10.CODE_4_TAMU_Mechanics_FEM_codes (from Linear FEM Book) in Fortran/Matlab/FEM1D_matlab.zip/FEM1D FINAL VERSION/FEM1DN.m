function FEM1DN
%
%*********************************
%           * Program FEM1D *
%* (A FINITE ELEMENT ANALYSIS COMPUTER PROGRAM) *
% *********************************
% _______________________________________________________________
% This is a finite element computer program for the analysis 
% of the following three model equations and others 
% (see also page 360 and following for description of considered problems) 
%
%| 1. Heat transfer, fluid mechanics, bars, and cables: 
%| CT.u* + CT.u** - (AX.u�)� + CX.u = FX 
%
%| 2. The Timoshenko beam and circular plate theory: 
%| CT0.w** - [AX.(w� + s)]� + CX.w = FX |
%| CT1.s** - (BX.s�)� + AX.(w� + s) = 0|
%
%| 3. The Euler-Bernoulli beam and circular plate theory: 
%| CT.w** + (BX.w��)�� + CX.w = FX |
%
%| In the above equations (�) and (*) denote differentiations |

%. .
%. KEY VARIABLES USED IN THE PROGRAM .
%. See Table 7.3.2 of the BOOK (3rd edition) for a description of the variables.
%. .
%. NDF....... Number of degrees of freedom per node .
%. NEQ....... Number of equations in the model (before B. C.) .
%. NGP....... Number of Gauss points used in the evaluation of .
%. the element coefficients, ELK , ELF , ELM .
%. NHBW...... Half bandwidth of global coefficient matrix GLK .
%. NN ....... Number of total degrees of freedom in the element .
%. NPE....... Number of nodes per element .
%_________________________________________________________________
%_________________________________________________________________
%. .
%. DIMENSIONS OF VARIOUS ARRAYS IN THE PROGRAM .
%. .
%. Values of MXELM,MXNOD, etc. in the PARAMETER statement should .
%. be changed to meet the requirements of the problem: .
%. .
%. MXELM..... Maximum number of elements in the mesh: .
%. MXEBC..... Maximum number of speci. primary deg. of freedom .
%. MXMBC..... Maximum number of speci. mixed boundary conditions .
%. MXNBC..... Maximum number of speci. secondary deg. of freedom .
%. MXNEQ..... Maximum number of equations in the FE model .
%. MXNOD..... Maximum number of nodes in the mesh .
%_________________________________________________________________
%. .
%. SUBROUTINES USED IN THE PROGRAM .
%. .
%. ASSEMBLE, BOUNDARY, COEFFCNT, CONSTRNT, ECHODATA, EQNSOLVR, .
%. EIGNSLVR, JACOBI, MATRXMLT, MESH1D, POSTPROC, REACTION, .
%. SHAPE1D, TIMFORCE, TIMSTRES, TRANSFRM .
%_________________________________________________________________

% filein =input('nome del file di input: ','s');
addpath('results\'); addpath('Subroutines\');
%% read input name
filename='Ex7-4-1';

if isempty(filename==1)
    prompt = {'Enter Input name:'};
    answer = inputdlg(prompt) 
    filename=answer{1}; %convert cell to string 
end
filein = join([filename,'.inp']);
fileout = join([filename,'.out']);

%% | PREPROCESSOR UNIT |
[data]=INPUT(filein); % read and store in "data" the input file. collect lines 110->314 of FEM1DN.for

%% print the input data
printINP(data,fileout) %collect lines 315->434 of FEM1DN.for

%% PROCESSOR UNIT
[data, GLF]=SOLVE(data,fileout);

%% print output data
if data.ITEM<3
    printOUT(data,GLF,fileout);
end
end


