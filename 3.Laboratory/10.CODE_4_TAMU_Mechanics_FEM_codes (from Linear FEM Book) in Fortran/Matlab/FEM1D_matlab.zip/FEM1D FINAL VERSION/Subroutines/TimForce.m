function[ELF,F3,FX]=TimForce(ELX,FX0,FX1,FX2,H,NTYPE,NE)

%     __________________________________________________________________        
%                                                                               
%        Called in COEFFICIENT to compute element force vector for the
%            consistent interpolation Timoshenko element (CIE)                        
%     __________________________________________________________________        
%                                                                               
ELF=zeros(1,6);
                                                                               
NPE=3;   %Quadratic variation of w in CIE beam element                                                                    
IEL=2;                                                                     
NDF=2;                                                                     
NGP=IEL+1;                                                                 
%                                                                               
EX=[ELX(1) ELX(1)+0.5*H ELX(2)];                                                                                                                     

[GAUSPT,GAUSWT]=lgwt(NGP,-1,1);                                                        

for NI=1:NGP
    XI=GAUSPT(NI);                                                         
    [GJ,SF,~,~,~,~]=shape1DMIO(H,IEL,NPE,XI);   
    CONST=GJ*GAUSWT(NI,NGP);
    X = SF*EX;
%                                                                               
%     Compute the polynomial variation of FX                                    
%                                                                               
    if(NTYPE==2)
        FX=FX0+(FX1+FX2*X)*X;                                                 
    else
        FX=(FX0+FX1*X)*X;    % Make sure that FX2=G13*K is not included                                                  
    end
%                                                                               
%     Element force vector for the consistent interpolation beam element        
%                                                                               
    II=1;                                                                      
    for I=1:NPE                                                             
        ELF(II)=ELF(II)+FX*SF(I)*CONST;                                            
        II=NDF*I+1;
    end
end
%                                                                               
%     Rearrange the element coefficients for the CIE element                                       
%                                                                               
F3(NE)=ELF(3);   % force associated with the midside node                                                          
ELF(1)=ELF(1)+0.5*F3(NE);                                                  
ELF(2)=-0.125*F3(NE)*H;                                                    
ELF(3)=ELF(5)+0.5*F3(NE);                                                  
ELF(4)= 0.125*F3(NE)*H;                                                    
end