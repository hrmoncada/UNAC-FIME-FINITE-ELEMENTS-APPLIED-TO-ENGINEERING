function[GJ,SF,DSF,DDSF,GDSF,GDDSF]=SHAPE(H,IELEM,NPE,XI)                                          
%     __________________________________________________________________        
%                                                                               
%      Called in COEFFFICIENT and in postprocessor 
%      to compute shape functions and their derivatives
%      for Hermite cubi% and Lagrange linear, quadrati% and cubic elements          
%                                                                               
%      X.........  Global (i.e., problem) coordinate                          
%      XI .......  Local (i.e., element) coordinate                           
%      H.........  Element length                                             
%      {SF}......  Interpolation (or shape) functions                         
%      {DSF}.....  First derivative of SF w.r.t. XI                           
%      {DDSF}....  Second derivative of SFH w.r.t. XI                         
%      {GDSF}....  First derivative of SF w.r.t. X                            
%      {GDDSF}...  Second derivative of SFH w.r.t. X                          
%      GJ........  Jacobian of the transformation                             
%     __________________________________________________________________        
%                                                                               
       
if (IELEM==3)%     HERMITE interpolation functions (for the Euler-Bernoulli theory)                                                        
    NET=4 ;                                                                
    SF(1)  = 0.25*(2.0-3.0*XI+XI^3);                                       
    SF(2)  =  -H*(1.0-XI)*(1.0-XI*XI)/8.0;                                  
    SF(3)  = 0.25*(2.0+3.0*XI-XI^3);                                       
    SF(4)  =   H*(1.0+XI)*(1.0-XI*XI)/8.0;                                  
    DSF(1) = -0.75*(1.0-XI*XI);                                            
    DSF(2) =  H*(1.0+2.0*XI-3.0*XI*XI)/8.0;                                
    DSF(3) =  0.75*(1.0-XI*XI);                                            
    DSF(4) =  H*(1.0-2.0*XI-3.0*XI*XI)/8.0;                                
    DDSF(1)= 1.5*XI;                                                      
    DDSF(2)= 0.25*H*(1.0-3.0*XI);                                         
    DDSF(3)= -1.5*XI;                                                     
    DDSF(4)=-0.25*(1.0+3.0*XI)*H;                                         
else
    NET=NPE;                                                               
    if(IELEM == 1)
%                                                                               
%     LAGRANGE interpolation functions used for linear, quadrati% and           
%              cubi% approximation of second-order equations                    
%                                                                               
%     LINEAR interpolation functions                                            
%                                                                               
        SF  = [0.5*(1.0-XI) 0.5*(1.0+XI)];                                              
        DSF = [-0.5 0.5];                                                      
        DDSF= [0 0];                                                     
    else
       if(IELEM==2)
%                                                                               
%     QUADRATI% interpolation functions                                         
%                                                                               
            SF   = [-0.5*XI*(1.0-XI) 1.0-XI*XI 0.5*XI*(1.0+XI)];                                      
            DSF  = [-0.5*(1.0-2.0*XI) -2.0*XI 0.5*(1.0+2.0*XI)];                                   
            DDSF = [1 -2 1];                                                 
       else%                                                                               
%     CUBI% interpolation functions                                             
%                                                                               
               SF(1)  = 0.0625*(1.0-XI)*(9.0*XI*XI-1.);                        
               SF(2)  = 0.5625*(1.0-XI*XI)*(1.0-3.0*XI);                       
               SF(3)  = 0.5625*(1.0-XI*XI)*(1.0+3.0*XI);                       
               SF(4)  = 0.0625*(9.0*XI*XI-1.0)*(1.0+XI);                       
               DSF(1) = 0.0625*(1.0+18.0*XI-27.0*XI*XI);                      
               DSF(2) = 0.5625*(-3.0-2.0*XI+9.0*XI*XI);                       
               DSF(3) = 0.5625*(3.0-2.0*XI-9.0*XI*XI);                        
               DSF(4) = 0.0625*(18.0*XI+27.0*XI*XI-1.0);                      
               DDSF(1)= 0.0625*(18.0-54.0*XI);                               
               DDSF(2)= 0.5625*(-2.0+18.0*XI);                               
               DDSF(3)= 0.5625*(-2.0-18.0*XI);                               
               DDSF(4)= 0.0625*(18.0+54.0*XI);                               
       end
    end
end
%                                                                               
%     Compute derivatives of the interpolation functions w.r.t. X               
%                                                                               
GJ =  H*0.5;                                                               
GDSF(1:NET)  = DSF(1:NET)/GJ;                                                       
GDDSF(1:NET) = DDSF(1:NET)/GJ/GJ;                                                  
end 