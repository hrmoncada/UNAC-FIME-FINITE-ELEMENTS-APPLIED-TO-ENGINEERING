function[GLX,NOD]=MESH1D(NEM,NPE,DX)                     
%     __________________________________________________________________        
%                                                                               
%     The subroutine is called in INPUT to compute arrays {GLX} and [NOD]                 
%                                                                               
%        {GLX}.... Vector of global coordinates                                 
%        {DX}..... Vector of element lengths [DX(1) = node 1 coord.]            
%        [NOD].... Connectivity matrix                                          
%     __________________________________________________________________        
%                                                                               

GLX=zeros(1,NEM+1);
%                                                                               
%     Generate the elements of the connectivity matrix                          
%           
NOD(1,1:NPE)=1:NPE;
for n=2:NEM
    NOD(n,1:NPE)=NOD(n-1,end)-1+NOD(1,1:NPE);
end
%                                                                               
%     Generate global coordinates of the global nodes                           
%                                                                               
GLX(1)=DX(1);                                                              
if(NPE==2)
    for i=1:NEM
        GLX(i+1) = GLX(i) + DX(i+1);
    end
else
    for i=1:NEM                                                         
        ii=2*i;                                                                
        GLX(ii)   = GLX(ii-1) + 0.5*DX(i+1);                                     
        GLX(ii+1) = GLX(ii-1) + DX(i+1);
    end
end
end      