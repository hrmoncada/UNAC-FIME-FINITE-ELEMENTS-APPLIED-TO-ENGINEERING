function[data,GLK,GLM,GLF,IBDY]=BOUNDARY(data,GLK,GLM,GLF,NHBW)               
%     __________________________________________________________________        
%                                                                               
%     The subroutine is called in ElemCalc to implement specified boundary         
%      conditions on the assembled system of finite element equations               
%     __________________________________________________________________        
%                                                                               
        
%%     Impose boundary conditions for STATIC and TIME-DEPENDENT problems         
%  
data.NEQR=data.NEQ;
if(data.ITEM<=2)%     Include specified PRIMARY degrees of freedom
    if(data.NSPV~=0)
        for NB = 1:data.NSPV                                                 
            IE=(data.ISPV(NB,1)-1)*data.NDF+data.ISPV(NB,2);                                  
            IT=NHBW-1;                                                         
            I=IE-NHBW;                                                         
            for II=1:IT                                                     
                I=I+1;                                                             
                if(I >= 1)
                    J=IE-I+1;                                                      
                    GLF(I)=GLF(I)-GLK(I,J)*data.VSPV(NB);                              
                    GLK(I,J)=0;                                                  
                end                                                          
            end                                                          
            GLK(IE,1)=1.0;                                                     
            GLF(IE)=data.VSPV(NB);                                                  
            I=IE;                                                              
            for II=2:NHBW                                                   
                I=I+1;                                                             
                if (I <= data.NEQ)
                    GLF(I)=GLF(I)-GLK(IE,II)*data.VSPV(NB);                             
                    GLK(IE,II)=0;                        
                end                                                             
            end
        end
    end                                                                               
    if(data.NSSV~=0) %     Include specified SECONDARY degrees of freedom                            
        for NF = 1:data.NSSV                                                 
           NB=(data.ISSV(NF,1)-1)*data.NDF+data.ISSV(NF,2);                                  
           if(data.ITEM == 1);GLF(NB)=GLF(NB)+data.VSSV(NF)*data.DT;end                          
           if(data.ITEM ~= 1);GLF(NB)=GLF(NB)+data.VSSV(NF);end                             
        end
    end
    if (data.NNBC ~= 0)%     Include specified MIXED boundary conditions                               
        for IC=1:data.NNBC%                                                   
            NC=(data.INBC(IC,1)-1)*data.NDF+data.INBC(IC,2);                                  
            if (data.ITEM==1)
                GLK(NC,1)=GLK(NC,1)+data.ALFA*data.DT*data.VNBC(IC);                          
                GLF(NC)=GLF(NC)+data.DT*data.VNBC(IC)*(data.UREF(IC)-...
                                (1.0-data.ALFA)*data.GU0(NC));
            else
                GLK(NC,1)=GLK(NC,1)+data.VNBC(IC);                                  
                GLF(NC)=GLF(NC)+data.VNBC(IC)*data.UREF(IC);                             
            end
        end
    end
else % Impose boundary conditions for EIGENVALUE problems                        
%                                                                               
    if (data.NNBC~=0) %Include specified MIXED boundary conditions                               
        for IC=1:data.NNBC                                                   
            NC=(data.INBC(IC,1)-1)*data.NDF+data.INBC(IC,2);                                  
            GLK(NC,NC)=GLK(NC,NC)+data.VNBC(IC);                                    
        end
    end
    if (data.NSPV ~= 0)%     Include specified PRIMARY degrees of freedom                              
        IBDY=sort((data.ISPV(1:data.NSPV,1)-1)*data.NDF+data.ISPV(1:data.NSPV,2),'descend');
% % %         for I=1:data.NSPV
% % %             IMAX=IBDY(I);                                                     
% % %             for J=I:data.NSPV                                                   
% % %                 if (IBDY(J) >= IMAX);
% % %                     IMAX=IBDY(J);                                                  
% % %                     IKEPT=J;                                                       
% % %                 end
% % %             end
% % %             IBDY(IKEPT)=IBDY(I);                                              
% % %             IBDY(I)=IMAX;                                                      
% % %         end
        NEQR = data.NEQ;
        for I=1:data.NSPV                                                   
            IB=IBDY(I);                                                        
            if (IB < NEQR)
                NEQR1=NEQR-1;                                                  
                for II=IB:NEQR1                                            
                    for JJ=1:NEQR                                              
                        GLM(II,JJ)=GLM(II+1,JJ);                                       
                        GLK(II,JJ)=GLK(II+1,JJ);                                       
                    end
                    for JJ=1:NEQR                                              
                        GLM(JJ,II)=GLM(JJ,II+1);                                       
                        GLK(JJ,II)=GLK(JJ,II+1);
                    end
                end
            end
            NEQR=NEQR-1;                                                       
        end
        data.NEQR=NEQR;                                                       

    end
% % % end

end                                                                             
                                                                                
    