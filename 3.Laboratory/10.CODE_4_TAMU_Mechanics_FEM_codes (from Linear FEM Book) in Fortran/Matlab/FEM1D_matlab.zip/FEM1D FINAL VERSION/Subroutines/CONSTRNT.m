function [GLM,GLK,GLF]=CONSTRNT(GLK,GLF,data)                
%     ____________________________________________________________________        
%                                                                               
%     The subroutine is called in ElemCalc to implement specified constraint 
%      conditions (e.g., inclined supports) on the condensed system of   
%      equations. Array GLM is used here as a temporary storage array.              
%     ____________________________________________________________________        
%                                                                               
%                                                                               
%     Include specified constraint conditions                               
% 
GLM=zeros(NEQ);
TRM=eye(NEQ);
for IC=1:NCON   
    BETA=data.VCON(IC)*pi/180;                                       
    IDOF=data.NDF*data.ICON(IC)-1;  
	TRM(IDOF,IDOF)    = cos(BETA);
    TRM(IDOF,IDOF+1)  = sin(BETA);
	TRM(IDOF+1,IDOF)  =-sin(BETA);
   TRM(IDOF+1,IDOF+1)= cos(BETA);
end
L=0;
for I=1:NEQ
    for J=1:NHBW                                                               
        GLM(I,L+J)=GLK(I,J);    
    end
    L=L+1;
end
for I=1:NEQ 
    for J=I:NEQ                                                              
        GLM(J,I)=GLM(I,J);
    end
end
GLK=TRM*GLK*TRM;
TRM=GLK;    
L=0;
for I=1:NEQ
    for J=1:NHBW                                                               
        GLK(I,J)=TRM(I,L+J);
    end
    L=L+1;
end
GLF=TRM*GLF'; 
end
              
			                                                            
    