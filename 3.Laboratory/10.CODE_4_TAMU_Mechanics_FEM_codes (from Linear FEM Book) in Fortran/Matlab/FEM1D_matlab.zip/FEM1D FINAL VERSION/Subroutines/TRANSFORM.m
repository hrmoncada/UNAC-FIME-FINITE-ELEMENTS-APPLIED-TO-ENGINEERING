function [ELK,ELM, ELF]=TRANSFORM(data,N,FTHER)                                   
%     __________________________________________________________________        
%                                                                               
%     Called in both ElemCalc and REACTION to compute stiffness matrix and 
%      force vector for the truss (NDF=2) and frame (NDF=3) elements                       
% 
%     ES......Element 'spring constant'                                                                              
%     SE......Young's modulus                                                   
%     SL......Element length                                                    
%     SA......Cross-sectional area                                              
%     SI......Moment of inertia                                                 
%     CS......Cosine of the angle of orientation                                
%     SN......Sine of the angle of orientation                                  
%     HF......UNIFORMALY distributed force along the length of the element                 
%     VF......UNIFORMLY distributed force transverse to the element                       
%     PF......Point force at point other than nodes                             
%     XB......Distance along the length from node 1 of the element              
%             of the location of the point force, PF                            
%     CNT,SNT:Direction cosines of the point force's line of application        
%     __________________________________________________________________        
%  


MODEL=data.MODEL;
NTYPE=data.NTYPE;

if(MODEL==0)
    ES=data.ES(N);
    ELK=[ES -ES
        -ES  ES];
    ELF=[-FTHER FTHER];                                                    
else
    CS=data.CS(N);SN=data.SN(N);
    cn=[CS SN];
    CN=cn'*cn;                                                                  
%                                                                               
%     Element coefficients in the global coordinates                                                      
%   
    SA=data.SA(N);SL=data.SL(N);SE=data.SE(N); HF=data.HF(N);
    if(NTYPE==0)
%                                                                               
%     The plane TRUSS element                                               
%         
        C1=SA*SE/SL;  
        ELK=C1*[CN -CN
               -CN CN];
%                                                                               
%     Contribution of the point force to nodal forces                       
%                                                                               
%*            XI=XB(N)/SL(N)                                                        
%*            SFL1 = 1.0-XI                                                         
%*            SFL2 = XI                                                             
%                                                                              
        F1=0.5*HF*SL-FTHER;                                                
        F3=0.5*HF*SL+FTHER;                                                    
        ELF = [F1*cn F3*cn];                                                        
    else
        if(NTYPE==1) %     The EULER-BERNOULLI FRAME element
            SI=data.SI(N);
            mu=0.5*SA*SL*SL/SI; %eq 3.129
            b=SE*SI;
            h=SL;
            K=2*b/h^3*[mu    0     0    -mu     0    0
                        0    6   -3*h    0     -6  -3*h
                        0   -3*h  2*h^2  0    3*h   h^2
                       -mu    0     0    mu     0    0
                        0    -6   3*h    0      6   3*h  
                        0   -3*h  h^2    0     3*h  2*h^2];
            ax=CS;ay=SN;
            rot=[ax  ay  0   0   0   0
                -ay  ax  0   0   0   0
                  0   0  1   0   0   0
                  0   0  0   ax  ay  0
                  0   0  0  -ay  ax  0
                  0   0  0   0    0  1];
               
            ELK=rot'*K*rot;      %     Element coefficients in the global coordinates  
%                                                                               
%     Contribution of the point force to nodal generalized forces           
%
            VF=data.VF(N);PF=data.PF(N);XB=data.XB(N);
            CNT=data.CNT(N);SNT=data.SNT(N);
            XI=XB/SL;                                                    
            TF=PF*SNT;                                                   
            AF=PF*CNT;                                                   
            SFL1 = 1.0-XI;                                                     
            SFL2 = XI;                                                         
            SFH1 = 1.0 - 3.0*XI*XI + 2.0*(XI^3);                              
            SFH2 = -XI*(1.0+XI*XI-2.0*XI)*SL;                               
            SFH3 = 3.0*XI*XI - 2.0*(XI^3);                                    
            SFH4 = -XI*(XI*XI - XI)*SL;                                     
%                                                                               
            F1=0.5*HF*SL         + SFL1*AF;                              
            F2=0.5*VF*SL         + SFH1*TF;                              
            F3=-VF*SL*SL/12.0 + SFH2*TF;                              
            F4=0.5*HF*SL         + SFL2*AF;                              
            F5=0.5*VF*SL         + SFH3*TF;                              
            F6=VF*SL*SL/12.0     + SFH4*TF;
               
            f=[F1 F2 F3 F4 F5 F6];
            ELF=rot'*f';
        end
%                                                                               
%     The TIMOSHENKO FRAME element (shear coefficient=5/6)                  
% 
        if (NTYPE >= 2)
            SG=5*SE/(1+PR)/12;                                   
            C1=SA*SE/SL;                                              
            C2=SG*SA/SL;                                                 
            C3=0.5*SG*SA;                                                   
            C4=0.25*SG*SA*SL;                                            
            C5=SE*SI/SL;
            K=[C1   0     0    -C1    0   0
               0    C2   -C3    0   -C2  -C3
               0   -C3 (C4+C5)  0    C3  (C4-C5)
              -C1   0     0    C1     0   0
               0   -C2    C3    0    C2   0
               0    -C3 (C4-C5)  0    C3 (C4+C5)];
            ax=CS;ay=SN;
            rot=[ax  ay  0   0   0   0
                -ay  ax  0   0   0   0
                  0   0  1   0   0   0
                  0   0  0   ax  ay  0
                  0   0  0  -ay  ax  0
                  0   0  0   0    0  1];                                        
            ELK=rot'*K*rot;      %     Element coefficients in the global coordinates                                                                  
%                                                                               
%     Contribution of the point force to nodal generalized forces           
%              
            XI=XB/SL;                                                    
            TF=PF*SNT;          % Transverse point load                                         
            AF=PF*CNT;          % Axial point load                                         
            SFL1 = 1.0-XI;                                                     
            SFL2 = XI;                                                         
            SFQ1 = (1.0-XI)*(1.0-2.0*XI);                                      
            SFQ2 = -XI*(1.0-2.0*XI);                                           
            SFQ3 = 4.0*XI*(1.0-XI);                                            
%              
            F1=0.5*HF*SL + SFL1*AF;   % HF = intensity of horizontally distributed force
			F4=0.5*HF*SL + SFL2*AF;     % VF = Intensity of transversly distributed force                           
            F2=0.5*VF*SL + (SFQ1+0.5*SFQ3)*TF;                   
            F5=0.5*VF*SL + (SFQ2+0.5*SFQ3)*TF;    
	        
            if (NTYPE == 2) % RIE element
                F3=0.0;                  
                F6=0.0;
            else% CIE element
			    F3=-VF*SL*SL/12.0 - 0.125*SFQ3*SL*TF;                  
                F6=VF*SL*SL/12.0  + 0.125*SFQ3*SL*TF;  
            end
            
            f=[F1 F2 F3 F4 F5 F6];
            ELF=rot'*f;
        end
    end
end
ELM=zeros(length(ELK));
end

