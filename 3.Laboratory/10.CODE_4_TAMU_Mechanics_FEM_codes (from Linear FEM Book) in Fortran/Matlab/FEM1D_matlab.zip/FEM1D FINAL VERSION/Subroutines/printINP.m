function printINP(data,fileout)

fid=fopen(fileout,'w');
fprintf(fid,'%s\n\n', data.Title{1}');

% A=[MODEL NTYPE ITEM NTHER];
fprintf(fid,'ANALYSIS OF MODEL %d, AND TYPE %d PROBLEM:',[data.MODEL data.NTYPE]);

switch data.MODEL
    case 0
        fprintf(fid,' a problem of discrete elements \n\n ');
    case 1
        switch data.NTYPE
            case 0
                fprintf(fid,' a problem described by model EQ 1 \n\n ');
            case 1
                fprintf(fid,' a circular DISK (PLANE STRESS) \n\n ');
            otherwise
                fprintf(fid,' a circular DISK (PLANE STRAIN) \n\n ');
        end
    case 2
        switch data.NTYPE
            case 0
                fprintf(fid,'   A Timoshenko beam (RIE) problem \n\n ');
            case 1
                fprintf(fid,'   A Timoshenko plate (RIE) problem \n\n ');
            case 2
                fprintf(fid,'   A Timoshenko beam (CIE) problem \n\n ');
            otherwise
                fprintf(fid,'   A Timoshenko plate (CIE) problem \n\n ');
        end
    case 3
        switch data.NTYPE
            case 0
                fprintf(fid,'   A Euler-Bernoulli beam problem \n\n ');
            otherwise
                fprintf(fid,'   A Euler-Bernoulli circular plate problem \n\n ');
        end
    case 4
        switch data.NTYPE
            case 0
                fprintf(fid,'   A plane truss problem \n ');
            case 1
                fprintf(fid,'   A Euler-Bernoulli frame problem \n ');
            case 2
                fprintf(fid,'   A Timoshenko (RIE) frame problem \n ');
            otherwise
                fprintf(fid,'   A Timoshenko (CIE) frame problem \n ');
        end
end
fprintf(fid,'   Element type (1 & 2 Lagrange; 3 Hermite) =  %d\n ',data.IELEM);
fprintf(fid,'   No. of deg. of freedom for node, NDF.... =  %d\n ',data.NDF);
fprintf(fid,'   No. of element in the MESH, NEM......... =  %d\n ',data.NEM);
fprintf(fid,'   No. of total DOF. in the model, NEQ..... =  %d\n ',data.NEQ);
fprintf(fid,'   Half bandwitch of matrix [GLK], NHBW.... =  %d\n ',data.NHBW);
fprintf(fid,'   No. of specified primary DOF, NSPV...... =  %d\n ',data.NSPV);
fprintf(fid,'   No. of specified secondary DOF, NSSV.... =  %d\n ',data.NSSV);
fprintf(fid,'   No. of specified Newton B.C.: NNBC...... =  %d\n ',data.NNBC);
fprintf(fid,'   No. of specified multi-pt cond.: NMPC... =  %d\n ',data.NMPC);

if(data.ITEM~=0)
    if(data.ITEM<=2)
        fprintf(fid,'\n\n   TIME-DEPENDENT (TRANSIENT) ANALYSIS: %d\n\n ',data.ITEM);
        if(data.ITEM==1)
            fprintf(fid,'   Coefficient CT0 of CT=CT0................= %12.4f\n ',data.CT0);
            fprintf(fid,'   Parameter, ALFA..........................= %12.4f\n ',data.ALFA);
            fprintf(fid,'   Time increment, DT.......................= %12.4f\n ',data.DT);
            fprintf(fid,'   No of Time steps, NTIME..................= %d\n ',data.NTIME);
            fprintf(fid,'   Time-step interval to print soln., INTVL = %d\n ',data.INTVL);
        else
            fprintf(fid,'   Coefficient CT0 of C1=CT0................= %12.4f\n ',data.CT0);
            fprintf(fid,'   Coefficient CT2 of C2=CT2................= %12.4f\n ',data.CT2);
            fprintf(fid,'   Parameter, ALFA..........................= %12.4f\n ',data.ALFA);
            fprintf(fid,'   Parameter, GAMA..........................= %12.4f\n ',data.GAMA);
            fprintf(fid,'   Time increment, DT.......................= %12.4f\n ',data.DT);
            fprintf(fid,'   No of Time steps, NTIME..................= %d\n ',data.NTIME);
            fprintf(fid,'   Time-step interval to print soln., INTVL = %d\n ',data.INTVL);
        end
        if (data.INCOND ~=0)
            fprintf(fid,'\n   Initial conditions of the primary variables: \n');
            fprintf(fid,'%15.5f',data.GU0, '  ');
            if (data.ITEM==2)
                fprintf(fid,'\n   Initial conditions on time der. of primary variables:, \n');
                fprintf(fid,'%15.5f',data.GU1, '  ');
            end
        end
    else
        if (data.ITEM==3)
            fprintf(fid,' \n\n       E I G E N V A L U E  A N A L Y S I S \n\n');
            if (data.MODEL==1)
                fprintf(fid,'   Coefficient CT0 of CT=CT0................= %12.4f\n ',data.CT0); 
            else
                fprintf(fid,'   Coefficient CT0 of C1=CT0................= %12.4f\n ',data.CT0);
                fprintf(fid,'   Coefficient CT2 of C2=CT2................= %12.4f\n ',data.CT2);
            end
        else
            fprintf(fid,'\n\n       B U C K L I N G  A N A L Y S I S \n\n');
        end
    end
end
if(data.NSPV~=0)
    fprintf(fid,'\n\n   Boundary information on primary variables:');
    if(data.ITEM <= 2)
        fprintf(fid,'  \n    %d    %d    %15.5e', [data.ISPV, data.VSPV]');
    else
        fprintf(fid,' \n    %d    %d', [data.ISPV]');
    end
end
if(data.NSSV~=0)
    fprintf(fid,'\n\n  Boundary information on secondary variables: \n');
    fprintf(fid,'  \n    %d    %d    %15.5e',[data.ISSV data.VSSV]');
end
if(data.NNBC~=0)
    fprintf(fid,'\n\n  Boundary information on mixed boudary cond.: \n');
    fprintf(fid,'  \n    %d    %d    %15.5e    %15.5e',[data.INBC, data.VNBC, data.UREF]');
end
if(data.NMPC~=0)
    fprintf(fid,'\n\n  Multi-point constraint information:  \n');
    for N=1:size(data.IMC1,1)
        fprintf(fid,'\n    %d   %d   %d   %d   %15.5e   %15.5e   %15.5e     %15.5e',data.IMC1(N,:), data.IMC2(N,:), data.VMPC(N,:));
    end
end

if(data.MODEL > 0 && data.MODEL < 4)
    fprintf(fid,' \n\n Global coordinates of the nodes, {GLX}: \n\n');
    fprintf(fid,'%15.5e',data.GLX);
    fprintf(fid,' \n\n Coefficients of the differential equation: \n');
    if (data.ICONT==1)
        if (data.ITEM~=3)
            fprintf(fid,'\n AX0= %15.5e   AX1= %15.5e   AX2= %15.5e   AX3= %15.5e   ',data.AX);
            fprintf(fid,'\n BX0= %15.5e   BX1= %15.5e   BX2= %15.5e   BX3= %15.5e   ',data.BX);
            fprintf(fid,'\n CX0= %15.5e   CX1= %15.5e   ',data.CX);
            fprintf(fid,'\n FX0= %15.5e   FX1= %15.5e   FX2= %15.5e   ',data.FX);
            if (data.NTHER~=0)
                fprintf(fid,'   Coefficient of thermal expansion, ...CTE  = %f12.4\n ',data.CTE);
                fprintf(fid,'   Temperature increment,...............TEMP = %f12.4\n ',data.TEMP);
            end
        else
            fprintf(fid,'\n AX0= %15.5e   AX1= %15.5e   AX2= %15.5e   AX3= %15.5e   ',data.AX);
            fprintf(fid,'\n BX0= %15.5e   BX1= %15.5e   BX2= %15.5e   BX3= %15.5e   ',data.BX);
            fprintf(fid,'\n CX0= %15.5e   CX1= %15.5e   ',data.CX);                
        end
    else
        if(data.ITEM ~= 3)
            fprintf(fid,'\n%12s %14s %15s %16s\n','AX0','AX1','AX2','AX3');
            fprintf(fid,'%15.5e %15.5e %15.5e %15.5e\n',data.DCAX');
            fprintf(fid,'\n%12s %14s %15s %16s\n','BX0','BX1','BX2','BX3');
            fprintf(fid,'%15.5e %15.5e %15.5e %15.5e\n',data.DCBX');
            fprintf(fid,'\n%12s %14s\n','CX0','CX1');
            fprintf(fid,'%15.5e %15.5e\n',data.DCCX');
            fprintf(fid,'\n%12s %14s %15s\n','FX0','FX1','FX2');
            fprintf(fid,'%15.5e %15.5e %15.5e\n',data.DCFX');
            if (data.NTHER ~= 0)
                fprintf(fid,'\n  Coefficient of thermal expansion, ...CTE  = ');
                fprintf(fid,'%15.5e ',data.DCTE');
                fprintf(fid,'\n  Temperature increment,...............TEMP = ');
                fprintf(fid,'%15.5e ',data.DTEMP');
            end
        else
            fprintf(fid,'\n%12s %14s %15s %16s\n','AX0','AX1','AX2','AX3');
            fprintf(fid,'%15.5e %15.5e %15.5e %15.5e\n',data.DCAX');
            fprintf(fid,'\n%12s %14s %15s %16s\n','BX0','BX1','BX2','BX3');
            fprintf(fid,'%15.5e %15.5e %15.5e %15.5e\n',data.DCBX');
            fprintf(fid,'\n%12s %14s\n','CX0','CX1');
            fprintf(fid,'%15.5e %15.5e\n',data.DCCX');                            
        end
    end
else
    if(data.MODEL==0)
        fprintf(fid,'   \n\nValues of the spring constants: = ');
        fprintf(fid,'   %15.5e ',data.ES);
    else
        for N=1:data.NEM
            fprintf(fid,'\n\n    Element No. = %d\n ',N);                                                       
            if (data.NTYPE~=0)
                fprintf(fid,'\n   The Poisson ratio,            PR........= %e12.4\n ',data.PR(N));                                                       
                fprintf(fid,'   Modulus of elasticity,        SE........= %e12.4\n ',data.SE(N));   
                fprintf(fid,'   Length of the element,        SL........= %e12.4\n ',data.SL(N));
                fprintf(fid,'   Area of cross section,        SA........= %e12.4\n ',data.SA(N));
                fprintf(fid,'   Moment of Inertia,            SI........= %e12.4\n ',data.SI(N));
                fprintf(fid,'   Cosine of orientation,        CS........= %e12.4\n ',data.CS(N));   
                fprintf(fid,'   Sin of orientation,           SN........= %e12.4\n ',data.SN(N));
                fprintf(fid,'   Axial body force (constant),  HF........= %e12.4\n ',data.HF(N));   
                fprintf(fid,'   Transverse body force (cnst), VF........= %e12.4\n ',data.VF(N));
                fprintf(fid,'   Internal point force,         PF........= %e12.4\n ',data.PF(N));
                fprintf(fid,'   Location of PF from node 1,   XB........= %e12.4\n ',data.XB(N));   
                fprintf(fid,'   Orientation of PF: cosine,    CST.......= %e12.4\n ',data.CNT(N));   
                fprintf(fid,'   Orientation of PF: sin,       SNT.......= %e12.4\n ',data.SNT(N)); 
                fprintf(fid,'   Nodal connectivity,           NOD(i,j)..= %d %d\n ',data.NOD(N,1) ,data.NOD(N,2)); 


            else
                fprintf(fid,'   Modulus of elasticity,        SE........= %e12.4\n ',data.SE(N));   
                fprintf(fid,'   Length of the element,        SL........= %e12.4\n ',data.SL(N));
                fprintf(fid,'   Area of cross section,        SA........= %e12.4\n ',data.SA(N));
                fprintf(fid,'   Cosine of orientation,        CS........= %e12.4\n ',data.CS(N));   
                fprintf(fid,'   Sin of orientation,           SN........= %e12.4\n ',data.SN(N));
                fprintf(fid,'   Axial body force (constant),  HF........= %e12.4\n ',data.HF(N));   
                fprintf(fid,'   Nodal connectivity,           NOD(i,j)..= %d %d\n ',data.NOD(N,:)); 
                if(data.NTHER~=0)
                    fprintf(fid,'   Coefficient of thermal exoansion, CTE........= %e12.4\n ',data.CTE(N));   
                    fprintf(fid,'   Temperature increment,            TEMP.......= %e12.4\n ',data.NOD(N,:)); 
                end
            end
        end
    end
end

fclose(fid);
end

