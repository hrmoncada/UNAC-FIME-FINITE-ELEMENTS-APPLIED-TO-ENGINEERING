function REACTION(GLF,data,fid)
%             
%     __________________________________________________________________        
%                                                                               
%      The subroutine is called in printOUT to compute generalized reaction
%     forces in each element of truss (NDF=2) or frame (NDF=3) structure               
%     __________________________________________________________________        
%                                                                               

FTHER=0;
if (data.MODEL == 0)
    ES=data.ES(N);
    for N=1:NEM    
        ELK = [ES -ES
              -ES  ES];
	    
        if(data.NTHER > 0);FTHER=data.DCTE(N)*data.DTEMP(N)*data.ES(N)*data.SL(N);end 
        
        ELF = [-FTHER FTHER];                                                
        NI  = data.NOD(N,1:NPE);  
        ELU = data.GLF(NI);
        ELR = ELK*ELU'-data.ELF; %Thermal forces are subtracted (assumeing no body force)
%          WRITE(6,170)N, (ELR(K),K=1,NPE) 
    end
else
    for N=1:data.NEM                                                            
        CN1=data.CS(N);                                                                 
        SN1=data.SN(N);                                                                 
%                                                                               
%     Call TRANSFORM to compute element stiffness matrix and force vector
%        
        L=0;                                                                       
        for I=1:data.NPE                                                            
           NI=data.NOD(N,I);                                                               
           LI=(NI-1)*data.NDF;                                                             
           for J=1:data.NDF                                                            
               LI=LI+1;                                                                   
               L=L+1;                                                                                    
               ELU(L)=GLF(LI);
           end
        end
        if (data.NTHER ~= 0);FTHER=data.DCTE(N)*data.DTEMP(N)*data.SE(N)*data.SA(N);end    
            [ELK,ELM,ELF]=TRANSFORM(data,N,FTHER);                                           
%                                                                               
%     Compute the FORCE and MOMENT RESULTANTS (assuming no axially distributed load)                                 
%        
            ELR=ELK*ELU'-ELF';
            if(data.NTYPE==0)
                ELF(1) =  ELR(1)*CN1+ELR(2)*SN1;                                           
                ELF(2) = -ELR(1)*SN1+ELR(2)*CN1;                                          
                ELF(3) =  ELR(3)*CN1+ELR(4)*SN1;                                     
                ELF(4) = -ELR(3)*SN1+ELR(4)*CN1;
                fprintf(fid,'%d  %15.5e %15.5e %15.5e %15.5e\n',N,ELF');                                          
                fprintf(fid,'   %15.5e %15.5e %15.5e %15.5e\n',ELR');                                          

             else                                    
                ELF(1) =  ELR(1)*CN1+ELR(2)*SN1;                                        
                ELF(2) = -ELR(1)*SN1+ELR(2)*CN1;                                       
                ELF(3) =  ELR(3);                                 
                ELF(4) =  ELR(4)*CN1+ELR(5)*SN1;                                  
                ELF(5) = -ELR(4)*SN1+ELR(5)*CN1;                                
                ELF(6) =  ELR(6); 
                fprintf(fid,'%d  %15.5e %15.5e %15.5e %15.5e %15.5e %15.5e\n',N,ELF');                                          
                fprintf(fid,'%  %15.5e %15.5e %15.5e %15.5e %15.5e %15.5e\n',ELR'); 
            end
                                                         
    end
end

% % %   150 FORMAT (3X,I2,6E12.4)                                                     
% % %   160 FORMAT (5X,6E12.4,/)
% % %   170 FORMAT (5X,I2,3X,E14.5,3X,E14.5)                                                      
end                                                                                
   