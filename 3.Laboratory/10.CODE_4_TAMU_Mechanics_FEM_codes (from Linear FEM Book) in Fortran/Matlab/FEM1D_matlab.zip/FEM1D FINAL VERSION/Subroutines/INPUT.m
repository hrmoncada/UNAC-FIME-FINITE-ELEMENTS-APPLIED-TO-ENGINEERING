function [data]=INPUT(filein)
%
% preprocessor UNIT
%
fid=fopen(filein);         
Title = textscan(fid,'%q',1);
data.Title=Title{1};
% Title = textscan(fid,'%20s','EndOfLine',';');
data.NT=0;data.NSSV=0;data.JVEC=1;data.TIME=0.0D0;data.TOLRNS=1.0D-06; %EU: vedi se serve tolrns
 
%% see Data Card 2, page 371
% % mod=textscan(fid,'%n %n %n',1,'commentStyle', '//');
mod=textscan(fid,'%n %n %n %n',1,'commentStyle', '//');
MODEL=mod{1};%MODEL(1:4), NTYPE(0:3);:model and type of problem solved; 
NTYPE=mod{2};
ITEM=mod{3}; % ITEM (0:3): indicator for transient anlaysis;
NTHER=mod{4};
%% see Data Card 3, page 371
elem=textscan(fid,'%n %n',1,'commentStyle', '//');
IELEM=elem{1};NEM=elem{2};
%% see Data Card 4, page 371
icont=textscan(fid,'%n %n',1,'commentStyle', '//');
data.ICONT=icont{1}; % (0:1) indicator for continuity of data 
data.NPRNT=icont{2}; %(0:3)indicator for printing of element/global matrices

if (MODEL >= 3)
    NPE=2;  %for Euler-Bernoulli beam element all frame elements   
    if (MODEL==4 && NTYPE >= 1)
        NDF=3; %degree of freedom for any FRAME element
    else %(MODEL = 3 or NTYPE=0)
        NDF=2; % Bernoulli or plane truss problem
    end
    if (MODEL==4 && NTYPE ~= 1) %Timoshenko FRAME problem
        IELEM=1; %linear Lagrange: Frame elem wih linear approx. of u,w,phi
    else %Bernoulli or plane truss 
        IELEM=3; %Hermite cubic FE
    end
else
    if(MODEL==2) %Timoshenko beam or plate 
        NDF=2; 
        if (NTYPE > 1);IELEM=1; end %CIE problem: linear Lagr
    else %model=1
        NDF=1; 
    end
    NPE=IELEM+1; %model =1 or 2: number of nodes for elements=
end

if (MODEL == 0)
     NDF=1;
     NPE=2;
	 NTYPE=0;   % Making sure that it is a discrete element
	 IELEM=0;   % Making sure that it is a discrete element
end

%collect in data
data.NDF=NDF;data.NPE=NPE;
data.MODEL=MODEL; data.NTYPE=NTYPE;data.ITEM=ITEM;data.IELEM=IELEM;data.NEM=NEM;
data.NTHER=NTHER;
%% see Data Card 5
if (MODEL > 0 && MODEL < 4) %if not truss/frame model: Data input for BAR-LIKE and BEAM problems (MODEL=1,2, AND 3)
    NNM = NEM*(NPE-1)+1; % numer of global nodes in the mesh: valid for elements connected in series
    dx=textscan(fid,'%n',NEM+1,'commentStyle', '//');data.DX=dx{:}; %DX(1)=global coordinate node1; DX(2:end)=length (i-1 elem); 
    [GLX,NOD]=MESH1D(data.NEM,data.NPE,data.DX);
    data.GLX=GLX; %data.card11
    data.NOD=NOD;
    if (data.ICONT ~= 0)
        abc=textscan(fid,'%n %n %n %n %n %n %n %n %n %n',1,'commentStyle', '//');
%% see data card 6-9
        data.AX=[abc{1:4}];data.BX=[abc{5:8}];data.CX=[abc{9:10}]; %constant and linear terms of a(x),b(x),c(x);
        if(ITEM < 3)
            ff=textscan(fid,'%n %n %n',1,'commentStyle', '//'); data.FX=[ff{:}];
            if (NTHER ~= 0)
                temp=textscan(fid,'%n %n',1,'commentStyle', '//'); 
                data.CTE=temp{1};data.TEMP=temp{2};
            end
        else
            data.FX=[0 0 0];
        end
    else   %discontinuous data: Read GLX, NOD, and element-wise continuous coefficients [DC.X]
    %% see Data Card 10-15
% %         glx=textscan(fid,'%n',NEM,'commentStyle', '//'); %length of the Ith element 
% %         data.GLX=[glx{:}];

        dd=textscan(fid,'%n %n %n %n %n %n %n %n %n %n',NEM,'commentStyle', '//'); %constant and linear terms of AX, BX, CX, FX
        DCAX1=[dd{1:10:end}];DCAX2=[dd{2:10:end}]; DCAX3=[dd{3:10:end}];DCAX4=[dd{4:10:end}];
        DCBX1=[dd{5:10:end}];DCBX2=[dd{6:10:end}]; DCBX3=[dd{7:10:end}];DCBX4=[dd{8:10:end}];
        DCCX1=[dd{9:10:end}];DCCX2=[dd{10:10:end}]; 

        data.DCAX=[DCAX1 DCAX2 DCAX3 DCAX4];
        data.DCBX=[DCBX1 DCBX2 DCBX3 DCBX4];
        data.DCCX=[DCCX1 DCCX2];
        if (ITEM < 3)
            ff=textscan(fid,'%n %n %n',NEM,'commentStyle', '//'); %
            DCFX1=[ff{1:3:end}];DCFX2=[ff{2:3:end}]; DCFX3=[ff{3:3:end}];
            data.DCFX=[DCFX1 DCFX2 DCFX3];
        end
        if (NTHER ~= 0)
            temp=textscan(fid,'%n %n',NEM,'commentStyle', '//'); 
            data.DCTE=[temp{1:2:end}];data.DTEMP=[temp{2:2:end}];
        end
    end
    
else %Input data for systems with discrete elements (MODEL=0) - Static analysis only
    data.ITEM=0;
    if (data.MODEL== 0)
        nnm=textscan(fid,'%n',1,'commentStyle', '//');NNM=nnm{1};data.NNM=NNM;  
        es=textscan(fid,'%n %n %n',NEM,'commentStyle', '//');data.ES=es{1:3:end};  nod1=[es{2:3:end}];nod2=[es{3:3:end}];data.NOD=[nod1 nod2]; 
        if (data.NTHER ~= 0)
            temp=textscan(fid,'%n %n %n',NEM,'commentStyle', '//');
            data.DCTE=[temp{1:3:end}];  data.DTEMP=[temp{2:3:end}]; data.SL=[temp{3:3:end}];    
        end
    end
    %% see data card 16
    if (MODEL ==4)
        nnm=textscan(fid,'%n',1,'commentStyle', '//');NNM=nnm{1};data.NNM=NNM;  
        if (NTYPE ~= 0) %skyp for truss problems (frame structures)
%% data card 17-19        
            aaa=textscan(fid,'%n %n %n %n %n %n %n %n %n %n %n %n %n %n %n',NEM,'commentStyle', '//');
            PR=[aaa{1:15:end}];SE=[aaa{2:15:end}];SL=[aaa{3:15:end}];SA=[aaa{4:15:end}];% Poiss, Young, Lenght,cross sect Area, 
            SI=[aaa{5:15:end}];CS=[aaa{6:15:end}];SN=[aaa{7:15:end}]; % Inertia, Cosin and Sin of the element
            HF=[aaa{8:15:end}];VF=[aaa{9:15:end}];PF=[aaa{10:15:end}];XB=[aaa{11:15:end}]; %intensity of distributed horiz/transversely force, Point load, distance from node 1 along the length of the element 
            CNT=[aaa{12:15:end}];SNT=[aaa{13:15:end}]; %cosin/sin of the load PF
            
            nod1=[aaa{14:15:end}];nod2=[aaa{15:15:end}];NOD=[nod1 nod2]; %connectivity of the element

            data.PR=PR;data.SE=SE;data.SL=SL;data.SA=SA;data.SI=SI;data.CS=CS;data.SN=SN;
            data.HF=HF;data.VF=VF;data.PF=PF;data.XB=XB;data.CNT=CNT;data.SNT=SNT;
            data.NOD=NOD;
    
        else %truss problems
%% data card 20-21
    
            aaa=textscan(fid,'%n %n %n %n %n %n %n %n',NEM,'commentStyle', '//'); 
            SE=[aaa{1:8:end}];SL=[aaa{2:8:end}];SA=[aaa{3:8:end}]; %Young, Lenght,cross sect Area, 
            CS=[aaa{4:8:end}];SN=[aaa{5:8:end}];HF=[aaa{6:8:end}]; %, Cosin and Sin of the element;intensity of distributed horiz force
            nod1=[aaa{7:8:end}];nod2=[aaa{8:8:end}];        data.NOD=[nod1 nod2];  %connectivity of the element
            data.SE=SE;data.SL=SL;data.SA=SA;data.CS=CS;data.SN=SN;data.HF=HF;
            if (NTHER ~= 0)
                temp=textscan(fid,'%n %n ',NEM,'commentStyle', '//');
                data.DCTE=[temp{1:2:end}];  data.DTEMP=[temp{2:2:end}];
            end
        end
        
        %% data card 23
        ncon=textscan(fid,'%n ',1,'commentStyle', '//'); data.NCON=ncon{1}; %number of inclined support conditions
        
        if (data.NCON ~= 0)
            temp=textscan(fid,'%n %n',data.NCON,'commentStyle', '//'); 
            data.ICON=[temp{1:2:end}]; data.VCON=[temp{2:2:end}]; %global node and angle in degrees of the inclined supports
        end
    end
end
data.NNM=NNM;
data.NEQ=NNM*NDF; %Number of equations in the model (before B. C.):number of global nodes in the mesh x  number of DOF for node.
%% see Data Card 24-27
%Read data on BOUNDARY CONDITIONS of three kinds: Dirichlet (PV), Neumann (SV), and Newton�s (MIXED) types
nspv=textscan(fid,'%n',1,'commentStyle', '//'); 
data.NSPV=nspv{1};%number of specified primary DoF

if (data.NSPV ~= 0)
    if (data.ITEM > 2)%eigenvalue analysis;
          ispv=textscan(fid,'%n %n',data.NSPV,'commentStyle', '//'); ISPV=[ispv{:}]; %node number at which PV is specified
          data.ISPV=ISPV;
    else
        ispv=textscan(fid,'%n %n %n',data.NSPV,'commentStyle', '//'); ISPV=[ispv{:,1:2}]; VSPV=[ispv{:,3}];%node number and value
        data.ISPV=ISPV; 
        data.VSPV=VSPV;
    end
end

if (data.ITEM <= 2)
    nssv=textscan(fid,'%n',1,'commentStyle', '//'); data.NSSV=[nssv{:}]; %number of spefified, nonzero, secondary variables
    if (data.NSSV ~= 0)
         ispv=textscan(fid,'%n %n %n',data.NSSV,'commentStyle', '//'); data.ISSV=[ispv{:,1:2}]; data.VSSV=[ispv{:,3}];%node number and value
    end
end
%% see Data Card 28-29
nnbc=textscan(fid,'%n',1,'commentStyle', '//'); NNBC=nnbc{:}; %number of Newton (mixed) BC
data.NNBC=NNBC;
if (NNBC ~= 0) %mixed B.C. is assumed to be of the form: SV+VNBC*(PV-UREF)=0
    inbc=textscan(fid,'%n %n %n %n',NNBC,'commentStyle', '//'); INBC=[inbc{:,1:2}]; VNBC=[inbc{:,3}]; UREF=[inbc{:,4}];%node number, local DoF, PV and UREF coefficient 
    data.INBC=INBC;
    data.VNBC=VNBC;
    data.UREF=UREF;
end

%% see Data Card 30-31

%Read data on multi-point constraints (solid mechanics)
nmpc=textscan(fid,'%n',1,'commentStyle', '//'); NMPC=nmpc{:}; %number of multipoint constrains
data.NMPC=NMPC;
if (NMPC ~= 0) %multipoint conditions are assumed to be of the form: vmpc1*PV1+vmpc2*PV2=vmpc3;
    imc=textscan(fid,'%n %n %n %n %n %n %n %n',NMPC,'commentStyle', '//'); 
    IMC1=[imc{:,1:2}]; IMC2=[imc{:,3:4}]; VMPC=[imc{:,5:8}];%node number and loca DOF of PV1 and PV2; 
                                                      %VMPV(1:3) values of the coefficientrs of the constraint eq; VMPV(4): value of the force appliet at the node of PV1 or PV2 
    data.IMC1=IMC1;data.IMC2=IMC2;data.VMPC=VMPC;
end
%% see Data Card 32
if (ITEM ~= 0) %Input data here for TIME-DEPENDENT problems
    if (ITEM <= 3)
        if (MODEL== 1)
            ct=textscan(fid,'%n ',1,'commentStyle', '//'); CT0=ct{1};data.CT0=CT0;%ct=CT0+CT1 x;
        else
            ct=textscan(fid,'%n %n',1,'commentStyle', '//'); CT0=ct{1};CT2=ct{2};
            data.CT0=CT0; data.CT2=CT2;
        end
    end
    
    if (ITEM <= 2) %skip id sterady state (ITEM=0) or eigenvalue (ITEM=3) analysis
        %% see Data Card 33-36
        if (ITEM ==1)
            dt=textscan(fid,'%n %n',1,'commentStyle', '//'); 
        else
            dt=textscan(fid,'%n %n %n',1,'commentStyle', '//'); data.GAMA=dt{3};  
        end
        data.DT=dt{1};  data.ALFA=dt{2}; %time increment, parameters in time approx scheme, 
        tmp=textscan(fid,'%n %n %n',1,'commentStyle', '//'); %indicator for initial condition (=0 homogeneus >0 non hom);number of time steps; time steps interval
        data.INCOND=tmp{1}; data.NTIME=tmp{2}; data.INTVL=tmp{3};

        if (data.INCOND ~= 0)
            guo=textscan(fid,'%n ',data.NEQ,'commentStyle', '//'); data.GU0=[guo{:}]'; %array of initial values of the primary variables
        else
            data.GU0=zeros(1,data.NEQ);
        end
        data.A1=data.ALFA*data.DT; data.A2=(1.0-data.ALFA)*data.DT;
        
        if (ITEM == 2)
           data.A3=2.0/data.GAMA/(data.DT^2);
           data.A4=data.A3*data.DT;
           data.A5=1/data.GAMA-1;
           if (data.INCOND ~= 0)
                gu=textscan(fid,'%n',data.NEQ,'commentStyle', '//'); GU1=[gu{1,:}]; GU2=zeros(1,data.NEQ);%array of initial values of the primary variables
           else
                GU1=zeros(1,data.NEQ);GU2=zeros(1,data.NEQ);
           end
           data.GU1=GU1;data.GU2=GU2;
        end
    end
end
%% | Compute the half BANDWIDTH of the coefficient matrix GLK|(Line 304)
%|_______________________________________________|
NHBW=0.0;
for i=1:data.NEM
    NW=(max(data.NOD(i,:))-min(data.NOD(i,:))+1)*data.NDF;
    if(NHBW <= NW); NHBW=NW;end
    
end

if(data.ITEM >= 3); NHBW=data.NEQ; end %line 445
data.NHBW=NHBW;
end