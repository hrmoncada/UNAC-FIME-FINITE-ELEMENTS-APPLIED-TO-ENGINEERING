function postprocessor(GLF,data,fid)             
%     __________________________________________________________________        
%                                                                               
%     The subroutine is called in printOUT to compute the solution and its
%     derivatives at  five points, including the nodes of the element. 
%     The bending moment (BM) and shear force (VF) are computed as per          
%     the definitions given in Fig. 5.2.1 and Eq. (5.3.1) of the book.                                  
%                                                                               
%        X........ Global (i.e., problem) coordinate                            
%        XI ...... Local (i.e., element) coordinate                             
%        SF....... Element interpolation (or shape) functions                   
%        GDSF..... First derivative of SF w.r.t. global coordinate              
%        GDDSF.... Second derivative of SF w.r.t. global coordinate             
%        ELU...... Element solution vector                                      
%        U........ Interpolated solution                                        
%        DU....... Interpolated derivative of the solution                      
%        W........ Interpolated transverse deflection                           
%        S........ Interpolated rotation function                               
%        DS....... Interpolated derivative of the rotation                      
%        DW....... Interpolated derivative of the transverse deflection         
%        DDW...... Interpolated second derivative of trans. deflection           
%        DDDW..... Interpolated third derivative of trans. deflection            
%     __________________________________________________________________        
%

XP=[-1.0 -0.75 -0.5 -0.25 0 0.25 0.5 0.75 1.0];                       
NPTS=9;                                                                    
for NE = 1:data.NEM                                                         
    if (data.ICONT ~= 1)
         AX=data.DCAX(NE,1:4);            %recalled in Coefficient
         BX=data.DCBX(NE,1:4);            %recalled in Coefficient
         CX=data.DCCX(NE,1:2);            %recalled in Coefficient
    else                                                      
        AX=data.AX;            %recalled in Coefficient
        BX=data.BX;            %recalled in Coefficient
        CX=data.CX;            %recalled in Coefficient
    end
    ELX(1:data.NPE)=data.GLX(data.NOD(NE,1:data.NPE));
    LI=[];
    for i=1:data.NPE
        LI=[LI (1:data.NDF)+((data.NOD(NE,i)-1)*data.NDF)];
    end
    ELU=GLF(LI);
    
    H = ELX(data.NPE) - ELX(1);                                                     
    for NI=1:NPTS                                                           
        XI = XP(NI);    
        [~,SF,~,~,GDSF,GDDSF]=SHAPE(H,data.IELEM,data.NPE,XI); 
        if(data.MODEL==3)
            XC=ELX(1)+0.5*H*(1.0+XI);                                              
            W  =SF*ELU';                                                 
            DW =GDSF*ELU';                                               
            DDW=GDDSF*ELU';                                              
            DDDW=((ELU(1)-ELU(3))*2.0/H-(ELU(4)+ELU(2)))*6.0/(H^2);                
            THETA=-DW;                                                               
            if (data.NTYPE==0)
                BM=-BX*[1 XC XC^2 XC^3]'*DDW;                                               
                VF=-BX*[1 XC XC^2 XC^3]'*DDDW - BX*[0 1 2*XC 3*XC^2]'*DDW;                                    
                fprintf(fid,'%15.5e %15.5e %15.5e %15.5e %15.5e \n',XC,W,THETA,BM,VF); 
            else
                ANU21=data.BX(1)*data.AX(1)/data.AX(2);                                                 
                DI=(data.BX(2)^3)/12.0;                                                  
                D11=DI*data.AX(1)/(1.0-data.BX(1)*ANU21);                                        
                D22=D11*(data.AX(2)/data.AX(1));                                                 
                D12=data.BX(1)*D22;                                                       
                BMR=-(D11*DDW*XC+D12*DW);                                             
                BMT=-(D12*DDW*XC+D22*DW);                                             
                if(XC ~= 0)
                    SFV=-D11*(XC*DDDW+DDW)+D22*DW/XC;
                    fprintf(fid,'%15.5e %15.5e %15.5e %15.5e %15.5e %15.5e\n',XC,W,THETA,BMR,BMT,SFV); 
%                     fprintf(fid,'Generalized internal forces in members \n');                               
                else
                      fprintf(fid,'%15.5e %15.5e %15.5e %15.5e %15.5e \n',XC,W,THETA,BMR,BMT); 
                end
            end
        else
            XC=SF*ELX';                                                    
            if(data.MODEL==1)
                U=SF*ELU';                                                  
                DU=GDSF*ELU';                                              
                if(data.NTYPE==0)
                    SV=AX*[1 XC XC^2 XC^3]'*DU; 
                    fprintf(fid,'%15.5e %15.5e %15.5e\n',XC,U,SV);
                else
                    ANU21=data.BX(1)*data.AX(1)/data.AX(2);                                             
                    if(data.NTYPE==1)
                        C11=data.BX(2)*data.AX(1)/(1-data.BX(1)*ANU21);                               
                        C22=C11*(data.AX(2)/data.AX(1));                                         
                        C12=data.BX(1)*C22;                                               
                    else                                                          
                        DENOM=1-data.BX(1)-ANU21;                                       
                        C11=data.BX(2)*data.AX(1)*(1.0-data.BX(1))/(1+data.BX(1))/DENOM;                     
                        C22=data.BX(2)*data.AX(2)*(1.0-ANU21)/(1.0+ANU21)/DENOM;                 
                        C12=data.BX(1)*C22;                                               
                    end                                                         
                    if(XC ~= 0)
                        SR=C11*DU+C12*U/XC;                                        
                        ST=C12*DU+C22*U/XC; 
                        fprintf(fid,'%15.5e %15.5e %15.5e %15.5e\n',XC,U,SR,ST); 
                    else                                                         
                        fprintf(fid,'%15.5e %15.5e %15.5e \n',XC,U,DU); 
                    end                                                        
                end                                                           
            else
    %                                                                  
    %     MODEL.EQ.2  Calculations       
    %                                       
                if(data.ITEM == 0 && data.NTYPE > 1)
                    H=ELX(NPE)-ELX(1);
                    [W,DW,PSI,DPSI] = TimStress(AX0,ELU,XI,NE,F3,H);               
                else
                    W   = SF*ELU(2*(1:data.NPE)-1)';                                          
                    DW  = GDSF*ELU(2*(1:data.NPE)-1)';                                                                                    
                    PSI = SF*ELU(2*(1:data.NPE))';                                                                                  
                    DPSI= GDSF*ELU(2*(1:data.NPE))';                                                                                  
                end
                if(data.NTYPE == 0 || data.NTYPE == 2)
                    BM=(data.BX(1)+data.BX(2)*XC)*DPSI;                                       
                    VF=(data.AX(1)+data.AX(2)*XC)*(DW+PSI);
                    fprintf(fid,'%15.5e %15.5e %15.5e %15.5e %15.5e\n',XC,W,PSI,BM,VF); 
                else                                      
                    ANU21=data.BX(1)*data.AX(1)/data.AX(2);                                         
                    DI=(data.BX(2)^3)/12.0;                                          
                    D11=DI*data.AX(1)/(1.0-data.BX(1)*ANU21);                                
                    D22=D11*(data.AX(2)/data.AX(1));                                         
                    D12=data.BX(1)*D22;                                               
                    BMR=(D11*DPSI*XC+D12*PSI);                                    
                    BMT=(D12*DPSI*XC+D22*PSI);                                    
                    SFV=FX2*(DW+PSI)*XC;
                    fprintf(fid,'%15.5e %15.5e %15.5e %15.5e %15.5e %15.5e\n',XC,W,PSI,BMR,BMT,SFV); 
                end
            end
        end
    end
end
end