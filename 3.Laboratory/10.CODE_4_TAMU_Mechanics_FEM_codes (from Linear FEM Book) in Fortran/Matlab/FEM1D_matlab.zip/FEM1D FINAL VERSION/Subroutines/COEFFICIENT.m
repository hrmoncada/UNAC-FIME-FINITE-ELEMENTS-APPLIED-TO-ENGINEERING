function [ELF,ELM,ELK]=COEFFICIENT(data,ELX,ELU,ELV,ELA,ax,bx,cx,fx,CTE,TEMP)       
%     __________________________________________________________________        
%                                                                               
%     The subroutine is called in ElemCalc to compute coefficient matrices
%      and source vector for the model problem in Eq. (1) (see MAIN)             
%                                                                               
%        X.........  Global (i.e., problem) coordinate                          
%        XI .......  Local (i.e., element) coordinate                           
%        H.........  Element length                                             
%        {SF}......  Element interpolation (or shape) functions                 
%        {GDSF}....  First derivative of SF w.r.t. X                            
%        {GDDSF}...  Second derivative of SF w.r.t. X                           
%        GJ........  Determinant of the Jacobian matrix [J]                             
%        [GAUSPT]..  4x4 matrix of Gauss points: N-th column corresponds        
%                    to the N-point Gauss rule                                  
%        [GAUSWT]..  4x4 matrix of Gauss weights (see the comment above)        
%        [A],[B],..  Element matrices needed to compute ELK                     
%        [ELK].....  Element coefficient matrix [K]                             
%        [ELM].....  Element 'mass' matrix [M]                                  
%     __________________________________________________________________        
%                                                                               
    
NDF=data.NDF;
NPE=data.NPE;

IELEM=data.IELEM;

%                                                                               
FTHER = 0.0;
NN=NDF*NPE;  
H = ELX(NPE) - ELX(1);
NGP = IELEM+1; %EU: IELEM=degree of aproximation: 0 (discrete), 1 (Linear) ... 3 (cubic)

[GAUSPT,GAUSWT]=lgwt(NGP,-1,1);      

% initialize
ELF = zeros(1,NN);
ELM=zeros(NN,NN);
ELK = zeros(NN,NN);

%                                                                               
if(data.MODEL ~= 2)% LOOP on number of Gauss points begins here                             
    for NI=1:NGP                                                                
        XI = GAUSPT(NI);                                                   
    %%     Call subroutine SHAPE1D to evaluate the interpolation functions and their global derivatives at the Gauss point XI                             
        [GJ,SF,~,~,GDSF,GDDSF]=SHAPE(H,IELEM,NPE,XI);                                               
        CONST = GJ*GAUSWT(NI);                                             
        if(IELEM==3)
            X = ELX(1) + 0.5*H*(1.0+XI);                                       
        else
            X = SF*ELX'; %eu check: dimension NPE
        end%                                                                               
    %     Compute coefficient matrices and vectors for various model problems        
    %         governed by single second-order and fourth-order equations            
    %                      (MODEL = 1 or 3; NTYPE = 0 or 1)                         
    %                                                                               
        CX=cx*[1 X]';
        if(data.NTHER ~= 0);FTHER=CTE*TEMP*ax(1);end
        if(data.ITEM ~= 3);FX=fx*[1 X X^2]';end                                              
        if(data.MODEL==1) % Coefficients for ALL SINGLE-VARIABLE PROBLEMS (MODEL=1)               
            if(data.NTYPE==0)% All problems governed by MODEL EQUATION (3.1) (NTYPE=0)           
                AX=ax*[1 X X^2 X^3]'; 
                if(data.ITEM <= 2);ELF = ELF + CONST*SF*FX + CONST*GDSF*FTHER;end
                if(data.ITEM ~= 0);ELM = ELM + CONST*(SF'*SF)*data.CT0;end                                                     
                AIJ = CONST*(GDSF'*GDSF);                                   
                CIJ = CONST*(SF'*SF);                                       
                ELK=ELK + AX*AIJ + CX*CIJ;
            else %     RADIALLY SYMMETRI% ELASTICITY problems (MODEL=1, NTYPE>0)         
    %            AX0=E1, AX1=E2, BX0=NU12, BX1=H, thickness                        
                ANU21=bx(1)*ax(1)/ax(2);                                             
                if(data.NTYPE==1)
                    C11=bx(2)*ax(1)/(1.0-bx(1)*ANU21);                               
                    C22=C11*(ax(2)/ax(1));                                         
                    C12=bx(1)*C22;                                               
                else
                    DENOM=1.0-bx(1)-ANU21;
                    C11=bx(2)*ax(1)*(1.0-bx(1))/(1.0+bx(1))/DENOM;                     
                    C22=bx(2)*ax(2)*(1.0-ANU21)/(1.0+ANU21)/DENOM;                 
                    C12=bx(1)*C22;                                               
                end
                for J=1:NN
                    if(data.ITEM<=2);ELF(J) = ELF(J) + CONST*SF(J)*FX*X;end                                                         
                    for I=1:NN                                                  
                        if(data.ITEM ~= 0);ELM(I,J) = ELM(I,J) + CONST*SF(I)*SF(J)*CT0*X;end              
                        AIJ = CONST*GDSF(I)*GDSF(J)*C11*X;                             
                        CIJ = CONST*SF(I)*SF(J)*CX*X;                                  
                        DIJ = CONST*(GDSF(I)*SF(J)+SF(I)*GDSF(J))*C12;                 
                        EIJ = CONST*SF(I)*SF(J)*C22/X;                                 
                        ELK(I,J)=ELK(I,J) + AIJ + CIJ + DIJ + EIJ;
                    end
                end
            end
        else %Coefficients for the EULER-BERNOULLI theory (MODEL=3)                 
            if(data.NTYPE==0) %The Euler-Bernoulli BEAM element (MODEL=3 and NTYPE=0)            
                BX=bx*[1 X X^2 X^3]';                                                  
                CX=cx*[1 X]';                                                  
                for J = 1:NN                                                
                    if(data.ITEM <= 2);ELF(J) = ELF(J) + CONST*SF(J)*FX; end
                    for I = 1:NN 
                        BIJ = CONST*GDDSF(I)*GDDSF(J);                                 
                        CIJ = CONST*SF(I)*SF(J);                                       
                        GIJ = CONST*GDSF(I)*GDSF(J);
                        if(data.ITEM > 0)
                            if(data.ITEM <= 3) %     Transient and vibration analysis
                                 ELM(I,J) = ELM(I,J)+data.CT0*CIJ+data.CT2*GIJ;        
                            else %     Buckling analysis
                                 ELM(I,J) = ELM(I,J) + GIJ;            
                            end
                        end
                        ELK(I,J)=ELK(I,J) + BX*BIJ + CX*CIJ;                           
                    end
                end
            else %       The E-B CIRCULAR PLATE element (MODEL=3 and NTYPE>0)                                                                            
    %              AX0=E1, AX1=E2, BX0=NU12, BX1=H, thickness                        
    %     (Needs modification to include transient and eigenvalue analysis)   
                ANU21=bx(1)*ax(1)/ax(2);                                             
                DI=(bx(2)^3)/12.0;                                              
                D11=DI*ax(1)/(1.0-bx(1)*ANU21);                                    
                D22=D11*(ax(2)/ax(1));                                             
                D12=bx(1)*D22;                                                   
                for J=1:NN                                                  
                    if (data.ITEM <= 2);ELF(J) = ELF(J) + CONST*SF(J)*FX*X;end                        
                    for I=1:NN                                                  
                        BIJ = CONST*GDDSF(I)*GDDSF(J)*D11*X;                           
                        CIJ = CONST*SF(I)*SF(J)*CX*X;                                  
                        DIJ = CONST*(GDDSF(I)*GDSF(J)+GDSF(I)*GDDSF(J))*D12;           
                        EIJ = CONST*GDSF(I)*GDSF(J)*D22/X;                             
                        ELK(I,J)=ELK(I,J) + BIJ + CIJ + DIJ + EIJ;                     
                    end
                end
            end
        end
    end
else% Coefficients for the TIMOSHENKO beam and circular plate (MODEL=2)         
%         Full integration for bending coefficients                             
    for NI=1:NGP                                                       
        XI=GAUSPT(NI);                                                     
        [GJ,SF,~,~,GDSF,~]=SHAPE(H,IELEM,NPE,XI);                                      
        CONST=GJ*GAUSWT(NI);                                               
        X = SF*ELX';
        if(data.NTYPE==0 || data.NTYPE == 2)% The Timoshenko RIE and CIE BEAM elements (MODEL=2 and NTYPE=0 OR 2)                
            BX=bx*[1 X X^2 X^3]';                                                      
            CX=cx*[1 X]';                                                      
            FX=fx*[1 X X^2]';                                              
            JJ=1;                                                              
            for J=1:NPE                                                    
                if (data.ITEM <= 2); ELF(JJ)=ELF(JJ)+FX*SF(J)*CONST;end
                II=1;                                                              
                for I=1:NPE                                                    
                    CIJ=SF(I)*SF(J)*CONST;                                             
                    BIJ=GDSF(I)*GDSF(J)*CONST;                                         
                    ELK(II,JJ)    =ELK(II,JJ)    +CX*CIJ;                              
                    ELK(II+1,JJ+1)=ELK(II+1,JJ+1)+BX*BIJ; 
                    if (data.ITEM > 0)
                        if (data.ITEM <= 3)
                            ELM(II,JJ)    =ELM(II,JJ)    +data.CT0*CIJ;                         
                            ELM(II+1,JJ+1)=ELM(II+1,JJ+1)+data.CT2*CIJ;                         
                        else
            			   ELM(II,JJ)    =ELM(II,JJ)    +BIJ;                         
                           ELM(II+1,JJ+1)=ELM(II+1,JJ+1)+BIJ*1.0D-16;                         
                        end
                    end
                    II=NDF*I+1;
                end
                JJ=NDF*J+1;
            end
        else %     Timoshenko CIRCULAR PLATE element (MODEL=2 and NTYPE=1 or 3)          
%                  AX0=E1, AX1=E2, BX0=ANU12, BX1=H, FX2 =G13*K               
            ANU21=bx(1)*ax(1)/ax(2);                                                 
            CX=cx*[1 X]';
            FX=fx*[1 X]';    % Make sure that FX2=G13*K is not included here                                                  
            DI=(bx(2)^3)/12.0;                                                  
            D11=DI*ax(1)/(1.0-bx(1)*ANU21);                                        
            D22=D11*(ax(2)/ax(1));                                                 
            D12=bx(1)*D22;                                                       
            JJ=1;                                                              
            for J=1:NPE                                                    
                if(ITEM <= 2);ELF(JJ)=ELF(JJ)+FX*SF(J)*CONST*X;end                                                
                II=1;                                                              
                for I=1:NPE                                                    
                    BIJ = CONST*GDSF(I)*GDSF(J)*D11*X;                                 
                    CIJ = CONST*SF(I)*SF(J)*X;                                         
                    DIJ = CONST*(GDSF(I)*SF(J)+SF(I)*GDSF(J))*D12;                     
                    EIJ = CONST*SF(I)*SF(J)*D22/X;                                     
                    ELK(II,JJ)     = ELK(II,JJ)     + CX*CIJ;                            
                    ELK(II+1,JJ+1) = ELK(II+1,JJ+1) + BIJ + DIJ + EIJ;                   
                    if (ITEM~=0)
                        ELM(II,JJ)     = ELM(II,JJ)     + CT0*CIJ;                         
                        ELM(II+1,JJ+1) = ELM(II+1,JJ+1) + CT2*CIJ;                         
                    end
                    II=NDF*I+1;
                end
                JJ=NDF*J+1;
            end
        end
    end % Reduced integration CAN BE used to evaluate the transverse shear terms        
    LGP=NGP;%     LGP=NGP-1;                                                             
    [GAUSPT,GAUSWT]=lgwt(LGP,-1,1);      
    for NI=1:LGP                                                       
        XI=GAUSPT(NI);                                                     
        [GJ,SF,~,~,GDSF,~]=SHAPE(H,IELEM,NPE,XI);                                      
        CONST=GJ*GAUSWT(NI);
        X = SF*ELX';
        if (data.NTYPE == 0 || data.NTYPE == 2)% The Timoshenko BEAM element (MODEL=2 and NTYPE=0 or 2)                
%         AX = GAK = AX0 + AX1*X  (reduced integration)                         
            AX=ax*[1 X X^2 X^3]'; % EU: potrebbe non trovarsi con le dimensioni: aggiungi degli zero;                                                      
            JJ=1;                                                              
            for J=1:NPE                                                    
                II=1;                                                              
                for I=1:NPE                                                    
                    B11=GDSF(I)*GDSF(J)*CONST;                                         
                    B01=SF(I)*GDSF(J)*CONST;                                           
                    B10=GDSF(I)*SF(J)*CONST;                                           
                    B00=SF(I)*SF(J)*CONST;                                             
                    ELK(II,JJ)    =ELK(II,JJ)    +AX*B11;                              
                    ELK(II,JJ+1)  =ELK(II,JJ+1)  +AX*B10;                              
                    ELK(II+1,JJ)  =ELK(II+1,JJ)  +AX*B01;                              
                    ELK(II+1,JJ+1)=ELK(II+1,JJ+1)+AX*B00;                              
                    II=I*NDF+1;
                end
                JJ=J*NDF+1;                                                        
            end
        else%     Timoshenko CIRCULAR PLATE element (MODEL=2 and NTYPE=1 or 3)          
%                BX1=H, FX2=G13*K (reduced integration)               
%                                                                               
            A33=BX1*FX2;                                                       
            JJ=1;                                                              
            for J=1:NPE                                                   
                II=1;                                                              
                for I=1:NPE                                                    
                    BIJ = CONST*GDSF(I)*GDSF(J)*X;                                     
                    CIJ = CONST*SF(I)*SF(J)*X;                                         
                    DIJ = CONST*GDSF(I)*SF(J)*X;                                       
                    DJI = CONST*SF(I)*GDSF(J)*X;                                       
                    ELK(II,JJ)    =ELK(II,JJ)     + A33*BIJ;                           
                    ELK(II,JJ+1)  =ELK(II,JJ+1)   + A33*DIJ;                           
                    ELK(II+1,JJ)  =ELK(II+1,JJ)   + A33*DJI;                           
                    ELK(II+1,JJ+1)=ELK(II+1,JJ+1) + A33*CIJ;                           
                    II=NDF*I+1;
                end
                JJ=NDF*J+1;
            end
        end
    end
    if(data.ITEM == 0 && data.NTYPE > 1)
        [ELF,~,~]=TimForce(ELX,FX0,FX1,FX2,H,NTYPE,NE);
    end
end

if(data.ITEM <=2)%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%EU : VEDI RETURN

    if(data.ITEM == 1 || data.ITEM == 2)% Equivalent coefficient matrices for TIME-DEPENDENT problems               
        if(data.ITEM == 1)% Alfa-family of time approximation for PARABOLIC equations             
            for J=1:NN                                                     
                SUM=0.0;                                                           
                for I=1:NN                                                     
                    SUM=SUM+(ELM(I,J)-data.A2*ELK(I,J))*ELU(I);                             
                    ELK(I,J)=ELM(I,J)+data.A1*ELK(I,J);                                     
                end
                ELF(J)=(data.A1+data.A2)*ELF(J)+SUM;                                         
            end
        else % Newmark-family of approximation for HYPERBOLI% equations              
            if(data.TIME == 0)
                ELF=ELF-(ELK*ELU')';                                 
                ELK=ELM;
            else
                ELF=ELF+(ELM*(data.A3*ELU+data.A4*ELV+data.A5*ELA)')';        
                ELK=ELK+data.A3*ELM;                                 
            end
        end
    end
end
end	                                                                      
                                                                                
   