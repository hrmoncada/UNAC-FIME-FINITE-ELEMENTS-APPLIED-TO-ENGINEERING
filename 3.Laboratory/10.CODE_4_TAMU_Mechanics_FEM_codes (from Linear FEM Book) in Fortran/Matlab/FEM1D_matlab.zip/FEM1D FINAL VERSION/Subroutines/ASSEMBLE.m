function [GLM,GLF,GLK]=ASSEMBLE(NOD,NDF,NPE,NE,ITEM,ELK,ELM,ELF,GLM,GLF,GLK)           
%     __________________________________________________________________        
%                                                                               
%       The subroutine is called in ElemCalc to assemble element coefficient
%       matrices (in a upper banded matrix form) and right-hand vectors 
%                                                                               
%        {ELF}.... Element source vector, {f}                                   
%        {ELK}.... Element coefficient matrix, [K]                              
%        {ELM}.... Element coefficient matrix, [M]                              
%        [NOD].... Connectivity matrix, [B]                                          
%     __________________________________________________________________        
%                                                                               

                                                                               
%%     Assemble element coefficient matrix ELK and source vector ELF             
%
if (ITEM <= 2)
% %     
% %     NCL = (NOD(NE,J)-1)*NDF;                                               
    for I = 1:NPE
        NR = (NOD(NE,I)-1)*NDF;
        for II = 1: NDF                                                     
            NR = NR + 1;                                                           
            L = (I-1)*NDF + II;                                                    
            GLF(NR) = GLF(NR) + ELF(L);                                            
            for J = 1:NPE                                                      
                NCL = (NOD(NE,J)-1)*NDF;                                               
                for JJ = 1:NDF                                                     
                    M = (J-1)*NDF + JJ;                                                    
                    NC = NCL-NR+JJ+1;
                    if (NC > 0);GLK(NR,NC) = GLK(NR,NC) + ELK(L,M);end
                end
            end
        end
    end
else                    
%                                                                               
%     ASSEMBLE ELEMENT MATRICES INTO FULL GLOBAL MATRICES                       
%
    NR=(NOD(NE,1))*NDF-NDF+1:(NOD(NE,1))*NDF;
    for i=2:NPE
        NR=[NR (NOD(NE,i))*NDF-NDF+1:(NOD(NE,i))*NDF];
    end
    
%     NC=(NOD(NE,1:NPE))*NDF;
    GLK(NR,NR)=GLK(NR,NR)+ELK;                                        
    GLM(NR,NR)=GLM(NR,NR)+ELM;                                        
end%
end                                                                                
 