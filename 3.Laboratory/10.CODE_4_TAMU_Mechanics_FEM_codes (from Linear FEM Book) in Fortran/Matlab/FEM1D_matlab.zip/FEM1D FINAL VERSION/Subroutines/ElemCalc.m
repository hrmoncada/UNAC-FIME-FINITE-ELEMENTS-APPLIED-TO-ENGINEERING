function[data,GLF]= ElemCalc (data,fileout)
%     ____________________________________________________________________        
%                                                                               
%     The subroutine is called in Solve to define the vector GLF. 
%     Penalty is also obtained, and stored in data.PNLTY
%     if eigenproblem solve and print eigenvalues and eigenvectors
%     ____________________________________________________________________        
%                                                                               
%                                                                               

%% initialize global matrices and vectors
GLF=zeros(1,data.NEQ);
% EU if (data.ITEM >= 3);GLM=zeros(data.NEQ,data.NHBW);end
GLM=zeros(data.NEQ);
GLK=zeros(data.NEQ);

ELU=[];ELV=[];ELA=[];FX=[]; %

%% loop for element calculations and assembly
for NE=1:data.NEM
    if (data.MODEL >0 && data.MODEL < 4)
        if (data.ICONT==0)
            AX=data.DCAX(NE,1:4);            %recalled in Coefficient
            BX=data.DCBX(NE,1:4);            %recalled in Coefficient
            CX=data.DCCX(NE,1:2);            %recalled in Coefficient
            if (data.ITEM~=3);FX=data.DCFX(NE,1:3);end           %recalled in Coefficient
            if (data.NTHER ~= 0)
                CTE=data.DCTE(NE);
                TEMP=data.DTEMP(NE);
            else
                CTE=0;TEMP=0;
            end
        else
            AX=data.AX;            %recalled in Coefficient
            BX=data.BX;            %recalled in Coefficient
            CX=data.CX;            %recalled in Coefficient
            FX=data.FX;
%             if (data.ITEM~=3);FX=data.FX;end            %recalled in Coefficient
            if (data.NTHER ~= 0)
                CTE=data.DCTE;
                TEMP=data.DTEMP;
            else
                CTE=0;TEMP=0;
            end
        end
        L=0;
        for i=1:data.NPE
            NI=data.NOD(NE,i);
            ELX(i)=data.GLX(NI);
            if (data.ITEM == 1 || data.ITEM == 2)
                LI=(NI-1)*data.NDF;
                for J=1:data.NDF
                    LI=LI+1; L=L+1;
                    ELU(L)=data.GU0(LI);
                    if (data.ITEM == 2 && data.NT  > 0)
                        ELV(L)=data.GU1(LI);
                        ELA(L)=data.GU2(LI);
                    end
                end
%             else
%                 ELU=[];ELV=[];ELA=[]; %EU: required in Coeffcnt
            end
        end
        [ELF,ELM,ELK]=COEFFICIENT(data,ELX,ELU,ELV,ELA,AX,BX,CX,FX,CTE,TEMP);
    else
       FTHER=0;
       if (data.NTHER ~= 0)
           if (data.MODEL == 0)
               FTHER=data.DCTE(NE)*data.DTEMP(NE)*data.ES(NE)*data.SL(NE);
           else
               FTHER=data.DCTE(NE)*data.DTEMP(NE)*data.SE(NE)*data.SA(NE);
           end
       end
       [ELK,ELM,ELF]=TRANSFORM(data,NE,FTHER); 
    end
    if (data.NPRNT ~= 0)
        %stampa
    end
    %% assemble
   [GLM,GLF,GLK]=ASSEMBLE(data.NOD,data.NDF,data.NPE,NE,data.ITEM,ELK,ELM,ELF,GLM,GLF,GLK);
    
end

if (data.MODEL ==4 && data.NCON ~= 0)
   [GLM,GLK,GLF]=CONSTRNT(GLK,GLF,data);        
end

%%     Impose multi-point constraints using the penalty method
if (data.NMPC ~= 0)
    if (data.NPRNT==2)
        %print data
    end
    VMAX=max(max(GLK));
    PNLTY=VMAX*1e4;
    data.PNLTY=PNLTY;
    for NC=1:data.NMPC
        NDOF1=(data.IMC1(NC,1)-1)*data.NDF+data.IMC1(NC,2);
        NDOF2=(data.IMC2(NC,1)-1)*data.NDF+data.IMC2(NC,2);
        GLK(NDOF1,1)=GLK(NDOF1,1)+PNLTY*data.VMPC(NC,1)*data.VMPC(NC,1);
	    GLK(NDOF2,1)=GLK(NDOF2,1)+PNLTY*data.VMPC(NC,2)*data.VMPC(NC,2);
	    GLF(NDOF1)=GLF(NDOF1)+PNLTY*data.VMPC(NC,1)*data.VMPC(NC,3);
        GLF(NDOF2)=GLF(NDOF2)+PNLTY*data.VMPC(NC,2)*data.VMPC(NC,3);
        if(NDOF1 > NDOF2)
            NW=NDOF1-NDOF2+1;
            GLK(NDOF2,NW)=GLK(NDOF2,NW)+PNLTY*data.VMPC(NC,1)*data.VMPC(NC,2);
            GLF(NDOF1)=data.VMPC(NC,4);
        else
            NW=NDOF2-NDOF1+1;
            GLK(NDOF1,NW)=GLK(NDOF1,NW)+PNLTY*data.VMPC(NC,1)*data.VMPC(NC,2);
            GLF(NDOF2)=data.VMPC(NC,4);
        end
    end
end
if (data.NPRNT==2)
    %print data
end            
%%     Call subroutine BOUNDARY to impose essential, natural and Newton's          
%     type boundary conditions on the primary and secondary variables.
[data,GLK,GLM,GLF]=BOUNDARY(data,GLK,GLM,GLF,data.NHBW);     
if (data.NPRNT==2)
    %print data
end   
if (data.ITEM >= 3)
    [EGNVEC,EGNVAL]=eig(GLK(1:data.NEQR,1:data.NEQR),GLM(1:data.NEQR,1:data.NEQR));%EU: 
    fid=fopen(fileout,'a');
    fprintf(fid,'\n\n    EIGENVALUES:');
    fprintf(fid,' %15.5e ',diag(EGNVAL));
    fprintf(fid,'  \n   SQRT(EGNVAL):');
    fprintf(fid,' %15.5e ',sqrt(diag(EGNVAL)));

    
    for i=1:data.NEQR
        fprintf(fid,'\n EIGENVECTORS %d : ',i);
        fprintf(fid,'%15.5e',EGNVEC(:,i));
    end
else
    IRES=0; %i think useless: it is a check per il solutore
    GLF= eqnsolvr(data.NEQ,data.NHBW,GLK,GLF,IRES);
    if data.ITEM==0
        fid=fopen(fileout,'a');
        fprintf(fid,'\n\n SOLUTION (values of PVs) at the NODES: \n ');
        fprintf(fid,'%15.5e',GLF);
    end
end