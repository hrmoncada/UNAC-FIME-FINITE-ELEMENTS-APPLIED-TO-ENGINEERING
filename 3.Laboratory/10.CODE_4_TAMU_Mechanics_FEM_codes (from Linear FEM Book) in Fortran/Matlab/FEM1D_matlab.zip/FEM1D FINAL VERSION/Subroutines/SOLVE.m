function [data,GLF] = SOLVE(data,fileout) 

 %% 
%  For ITEM=2, initial conditions
% on second derivatives of the solution are computed first before
%incremening the time step

[data,GLF]=ElemCalc(data,fileout); %lines 445-635
     
%% TIME MARCHING scheme begins here.

if (data.ITEM~=0 && data.ITEM < 3) 
    PRCNT=1; %initialize
    fid=fopen(fileout,'a');

    while(PRCNT>data.TOLRNS) 
% Compute and print current values of GU0, GU1, and GU2
        if (data.NT==0)
            fprintf(fid,'\n\n Acceleration vector at time t=0: \n ');
            fprintf(fid,'%15.5e',GLF);

            data.GU2=GLF;
            data.NT=data.NT+1;
            data.TIME=data.TIME+data.DT;
            [data,GLF]=ElemCalc(data); %lines 449-635

        end

        for I=1:data.NEQ  %compute and print current values of GU0, GU1 and GU2                                                      
            if(data.ITEM == 2)
               ACCLRN=data.A3*(GLF(I)-data.GU0(I))-data.A4*data.GU1(I)-data.A5*data.GU2(I);                     
               data.GU1(I)=data.GU1(I)+data.A2*data.GU2(I)+data.A1*ACCLRN;                                 
               data.GU2(I)=ACCLRN;                                                     
               data.GPU(I)=data.GU0(I);                                                     
            else
               data.GPU(I)=data.GU0(I);                                                     
            end                                                                 
            data.GU0(I)=GLF(I);
        end
    
        SOLN=data.GU0*data.GU0';  %SOLN+GU0(I)*GU0(I)
        DIFF=(GLF-data.GPU)*(GLF-data.GPU)'; %(GLF(I)-GPU(I))^2
        PRCNT=sqrt(DIFF/SOLN);
        if floor(data.NT/data.INTVL)==(data.NT/data.INTVL)
            fprintf(fid,'\n\n TIME =   %8.4e, TIme step number =   %d \n',[data.TIME data.NT]);
            fprintf(fid,'\n SOLUTION (values of PVs) at the NODES:\n');
            fprintf(fid,'%15.5e',GLF);
            if (data.ITEM ~=1 && data.NPRNT < 4)
                fprintf(fid,'\n FIRST TIME DERIVATIVE of the primary variables:\n');
                fprintf(fid,'%15.5e',data.GU1');
                fprintf(fid,'\n SECOND TIME DERIVATIVE of the primary variables:\n');
                fprintf(fid,'%15.5e',data.GU2');
            end
        end
        data.NT=data.NT+1;
        data.TIME=data.TIME+data.DT;
        if (data.NT-1 == data.NTIME)
           GLF=data.GPU;
           fprintf(fid,'\n\n     ***** Number of time steps exeeded NTIME *****');
           break
        end

        [data,GLF]=ElemCalc(data); %lines 449-635

    end
    if PRCNT <= data.TOLRNS   
        fprintf(fid,'\n\n\n  **** THE SOLUTION HAS REACHED A STEADY STATE **** \n');    
        fprintf(fid,'\n  SOLUTION AT THE TWO CONSECUTIVE TIME STEPS FOLLOWS: \n');    
        fprintf(fid,'%15.5e',data.GPU);
        fprintf(fid,'\n');    
        fprintf(fid,'%15.5e',data.GU0);

    end
end
end