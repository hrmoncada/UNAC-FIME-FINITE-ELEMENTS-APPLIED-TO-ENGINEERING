function printOUT(data,GLF,fileout)

fid=fopen(fileout,'a');

if(data.NMPC==0)
    if (data.NPRNT <= 1)
        fprintf(fid,'\n\n      ******* POST-PROCESSED SOLUTION******* \n ');
        if (data.MODEL)<=1
            fprintf(fid,'\n  ______________________________________________________\n ');
            if(data.MODEL==0)
                fprintf(fid,'Ele Force, P1 force, P2 \n ');                                                    
            else
                if(data.NTYPE==0)
                    fprintf(fid,'%10s %18s %18s','x','PV (U)','SV (a*DU)');                                                    
                else
                    fprintf(fid,'       x           Displacement    Radial Stress   Hoop Stress');                                                    
                end
            end
            fprintf(fid,'\n  ______________________________________________________\n ');
        end
        if(data.MODEL==2 || data.MODEL==3)
            fprintf(fid,'\n  _______________________________________________________________________________________________\n ');                                                 
            if(data.NTYPE==0)
                fprintf(fid,'\n        x            Deflect        Rotation         B. Moment     Shear Force \n ');                                                    
            else
                fprintf(fid,'       x             Deflect        Rotation        Moment, Mr      Moment, Mt     Shear Force \n ');                                                    
            end
            fprintf(fid,' _______________________________________________________________________________________________\n ');    
        end
        if (data.MODEL==4)
            fprintf(fid,'\n\n       Generalized internal forces in members \n'); 
            fprintf(fid,'(second lines gives the results in the global coordinates) \n'); 
            if (data.NTYPE==0)
                fprintf(fid,    '__________________________________________________________________________\n');  
                fprintf(fid,    '\nEle    Force, H1       Force, V1       Force, H2       Force, V2 \n');  
                fprintf(fid,    '__________________________________________________________________________\n');  
            else
                fprintf(fid,    '______________________________________________________________________\n');
                fprintf(fid,    '\nEle    Force, H1       Force, V1       Moment, M1       Force, H2        Force, V2       Moment, M2  \n');  
                fprintf(fid,    '______________________________________________________________________\n');  
            end
        end
    if(data.MODEL > 0 && data.MODEL < 4)
        postprocessor(GLF,data,fid); 
     
    else
        REACTION(GLF,data,fid)
                                                 
    end
       if (data.MODEL<=1)
           fprintf(fid,    '_____________________________________________________________');  
       else
           fprintf(fid,    '___________________________________________________________________________________');  
       end	
    end
else
%         
%     Calculate the reactions at the points where constraints are imposed
%            
    for NC=1:data.NMPC
        NDOF1=(data.IMC1(NC,1)-1)*data.NDF+data.IMC1(NC,2); 
        NDOF2=(data.IMC2(NC,1)-1)*data.NDF+data.IMC2(NC,2); 
        GU0(NC)=-data.PNLTY*data.VMPC(NC,1)*(data.VMPC(NC,1)*GLF(NDOF1)+data.VMPC(NC,2)*GLF(NDOF2)-data.VMPC(NC,3));
        GU1(NC)=-data.PNLTY*data.VMPC(NC,2)*(data.VMPC(NC,1)*GLF(NDOF1)+data.VMPC(NC,2)*GLF(NDOF2)-data.VMPC(NC,3));
    end
        fprintf(fid,'\n');
        fprintf(fid,' Forces at the constrained points: \n');  
        fprintf(fid,'%15.5e ',GU0'); 
        fprintf(fid,'\n');
        fprintf(fid,'%15.5e ',GU1'); 
        

end

end

