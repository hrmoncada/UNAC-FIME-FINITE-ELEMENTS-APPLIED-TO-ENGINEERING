function [W,DW,S,DS] = TimStress(GA,ELU,XI,NE,F3,H)                    
%     __________________________________________________________________        
%                                                                               
%     Called in postprocessor to compute solution and its global derivatives        
%       at nine points (including the nodes) of the Timoshenko element          
%                                                                               
%        XC........ Global (i.e., problem) coordinate                           
%        XI ....... Local (i.e., element) coordinate                              
%        SFL, SFQ.. Lagrange linear and quadrati% shape functions               
%        DSFL,DSFQ: First derivative of SF w.r.t. global coordinate             
%        ELU....... Column vector of generalized displacements                  
%        W, DW..... Transverse deflection and its derivative                    
%        S, DS..... Rotation and its derivative                                 
%     __________________________________________________________________        
%                                                                               
%                                                                               
      GJ =  H*0.5;                                                               
%                                                                               
%     Interpolation functions for the Lagrange LINEAR element                   
%                                                                               
      SFL(1) = 0.5*(1.0-XI);                                                     
      SFL(2) = 0.5*(1.0+XI);                                                     
      DSFL(1) = -0.5/GJ;                                                         
      DSFL(2) = 0.5/GJ;                                                          
%                                                                               
%     Interpolation functions for the Lagrange QUADRATI% element                
%                                                                               
      SFQ(1)  = -0.5*XI*(1.0-XI);                                                 
      SFQ(2)  = 1.0-XI*XI;                                                        
      SFQ(3)  = 0.5*XI*(1.0+XI);                                                  
      DSFQ(1) = -0.5*(1.0-2.0*XI)/GJ;                                            
      DSFQ(2) = -2.0*XI/GJ;                                                      
      DSFQ(3) = 0.5*(1.0+2.0*XI)/GJ;                                             
%                                                                               
      W3=(3.0*H*F3(NE)/GA + 8.0*(ELU(1)+ELU(3))+ 2*(ELU(4)-ELU(2))*H)/16;                         
      W =  SFQ(1)*ELU(1) + SFQ(2)*W3 + SFQ(3)*ELU(3);                            
      DW= DSFQ(1)*ELU(1) +DSFQ(2)*W3 +DSFQ(3)*ELU(3);                            
      S =  SFL(1)*ELU(2) + SFL(2)*ELU(4);                                        
      DS= DSFL(1)*ELU(2) +DSFL(2)*ELU(4);                                        
%                                                                               
end