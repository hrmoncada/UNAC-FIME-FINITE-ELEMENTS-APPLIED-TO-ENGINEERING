          INTRODUCTION TO FINITE ELEMENTS IN ENGINEERING
                        (Third Edition)

                   Tirupathi R. Chandrupatla
                      Ashok D. Belegundu              

		   Text ISBN: 0-13-061591-9
	       CD t/a Text ISBN: 0-13-008844-7

    This disk (CD) includes finite element programs.  There are seven
    directories on the CD.
        
    Directories
        \QBASIC   -  Source codes in QuickBasic
        \FORTRAN  -  Fortran source codes
        \C        -  Source codes in ANSI C
        \VB       -  Source codes in Visual Basic
        \EXCELVB  -  Programs in Microsoft Excel VBA       
        \MATLAB   -  Source codes in MATLAB


        \EXAMPLES -  This directory has input data files. There is a 
                     data file for each program. Same input data file
                     works for C, Fortran, Matlab, QuickBasic, and VB.
                     Excel has its own input in the spreadsheet.

    *** Copy the Programs from this CD onto your hard disk (writable disk) and then run 
	programs from the hard disk

    The program source codes are in text format. The programs can be run 
    on any PC or Workstation that has the compiler or interpreter for any
    of the above programming environments. Most of the programs are 
    transportable among Windows, Unix systems, IBM compatible PCs, Apple/Mac
    computers and Workstations where the compilers are available. 

    COMMENTS
      Visual Basic Programs
         - Each Visual Basic project consists of three files. The files have
           same name with extensions .vbp, .vbw, .frm
         - The .frm file has the form information and the source code
         - Make sure that all three files are in your directory while loading
           into Visual Basic
      C Programs
         -  All C programs were compiled and tested using ANSI C
         -  Dynamic memory allocation is used in declaring the arrays
      FORTRAN
         -  Array dimensions have been fixed at some values to enable 
            solution of small problems
         -  Look carefully at the array dimensions and match them in 
            the subroutines while attemting larger problems
      EXCEL
         -  Excel programs use the VBA (VB Application) environment
         -  The Excel programs have been developed on Microsoft Excel 2000
      QBASIC
         -  Quick Basic programs can be run using the QBASIC interpreter
            (QBASIC.EXE) provided on DOS, Windows 3.1, and Windows 95 
            environments or QuickBasic interpreter/compiler
      MATLAB
         -  Make sure that Bansol.m file is in the working directory
            along with the finite element program
   

    PROGRAMS ACCOMPANYING CHAPTERS

    Chapter 2       Chapter 3     Chapter 4
      GAUSS           FEM1D         TRUSS2D
      SKYLINE                       TRUSSKY
      CGSOL  

    Chapter 5        Chapter 6    Chapter 7
      CST              AXISY        QUAD
      QUADCG
      AXIQUAD

    Chapter 8        Chapter 9    Chapter 10
      BEAM             TETRA3D      HEAT1D
      FRAME2D          HEXAFRON     HEAT2D
      FRAME3D                       TORSION

    Chapter 11       Chapter 12       
      INVITR           MESHGEN   CONTOURA
      JACOBI           PLOT2D    CONTOUTB
      GENEIGEN         BESTFIT
      BEAMKM           BESTFITQ    
      CSTKM            

Note: PLOT2D, BESTFIT, BESTFITQ, CONTOURA, and CONTOURB are available in
      VB, QBasic, and MATLAB only.  QUADCG and AXIQUAD are not available
      in MATLAB.    


    MAIN VARIABLES

      All programs use the variables defined below:

        NN  -----  Number of Nodes
        NE  -----  Number of Elements
        NM  -----  Number of Different Materials
        NDIM  ---  Number of Coordinates per Node 
                   (e.g. NDIM = 2 for Two dimensional problems)
        NEN  ----  Number of Nodes per Element
                   (e.g. NEN = 3 for CST Elem)
        NDN  ----  Number of Degrees of Freedom per Node 
                   (e.g. NDN = 2 for BEAM)
        ND  -----  Number of Specified Displacement Degrees of Freedom(DOF)
        NL  -----  Number of Applied Component Loads (Along DOF directions)
        NPR  ----  Number of Material Properties (e.g. E, nu, alpha)
        NMPC  ---  Number of MultiPoint Constraints (of the type B1*Qi+B2*Qj=B3)


        The variables are also given inside the book cover.

        We encourage you to provide your feedback on the use of this book
        and the programs.


        Dr. T.R. Chandrupatla P.E.         Dr. A.D. Belegundu
        College of Engineering             Mechanical Engineering
        Rowan University                   The Pennsylvania State University
        Glassboro, NJ 08028                University Park, PA 16802
        e-mail: chandrupatla@rowan.edu	   e-mail: adb3@psu.edu

--------------------------------------------------------------------------------

PRENTICE HALL/PEARSON EDUCATION TECHNICAL SUPPORT
No technical support for this CD is offered by the authors, the software 
vendors, or Prentice Hall. 

However, if you have questions specifically relating to the installation 
process, you can contact Media Support by email at media.support@pearsoned.com 
or by calling 1-800-677-6337 between 8AM to 5PM CST Monday - Friday. 

You should have the following information ready: 
	* Product and Title and Product ISBN 
	* Computer Make and Model 
	* RAM Available 
	* Hard Disk Space Available 
	* Graphics Card Type 
	* Sound Card Type 
	* Printer Make And Model 
	* Network Connection 
	* Detailed description of the problem, including the  
	  exact wording of any error messages.

If you believe that your CD media is defective, you may send it to 
Prentice Hall to exchange for a replacement disk. The new disk can only 
be sent upon receipt of the defective disk. 

Send the defective disk, along with your name and address, to: 
	Computer Science Editor 
	Prentice Hall 
	1 Lake Street 
	Upper Saddle River, NJ 07458
